# Face Access — demonstração local

Aplicativo web local de cadastro e verificação facial. Requer Node.js 24 ou superior.

## OperSyncro

O documento [arquitetura do OperSyncro](./docs/arquitetura-opersyncro.md) descreve a arquitetura, o plano de evolução e os limites regulatórios. Há agora um **vertical slice demonstrativo**, não um produto de ponto certificado.

## Executar

1. Instale [Node.js 24+](https://nodejs.org/).
2. No terminal, nesta pasta, execute `npm install`.
3. Execute `npm start`.
4. Abra `http://localhost:3000` no navegador e permita o acesso à câmera.

No Windows, dê duplo clique em `Iniciar Face Access.bat` para iniciar o servidor em segundo plano e abrir o aplicativo quando ele estiver pronto. Também é possível executar `npm run start:windows`. Não abra `public/index.html` diretamente: o arquivo redireciona para `http://localhost:3000`, mas o servidor ainda precisa estar iniciado. Para iniciar automaticamente ao entrar no Windows, execute uma vez `npm run install:startup`; para remover essa opção, apague o atalho **Face Access** da pasta de Inicialização do usuário.

O reconhecimento é feito no navegador com SSD MobileNet e descritores faciais de 128 dimensões. O servidor mantém os templates cifrados em SQLite e compara três amostras por meio de uma distância Euclidiana configurada em 0,48. Essa configuração não é calibrada nem certificada para um uso laboral.

## Fluxo demonstrativo de jornada

- **Registrar ponto:** entrada, início/fim de intervalo ou saída. A marcação não depende de biometria, localização ou conexão.
- **Verificação facial opcional:** se escolhida, a tentativa usa o nome/identificador do cadastro facial e recebe uma assertion de uso único com validade curta. O servidor não confia no estado informado pelo cliente; como o PAD não está configurado, qualquer correspondência facial segue como `review_required`. Falha ou indisponibilidade não apaga nem bloqueia a marcação.
- **Fila offline:** o app-shell fica em cache pelo service worker; os eventos em espera são cifrados com WebCrypto no IndexedDB, assinados por uma chave ECDSA P-256 do dispositivo e sincronizados com chave de idempotência. A chave não é hardware-attested e o armazenamento web não protege contra script malicioso no mesmo origin. Sem sincronização, a marcação permanece provisória no dispositivo e ainda não tem recibo do servidor.
- **Auditoria:** eventos e revisões são encadeados por hash e HMAC, com restrições append-only no SQLite. Isso detecta algumas alterações, mas não é WORM, assinatura pública, nem proteção contra administrador/comprometimento do host.
- **Exceções:** o painel só é habilitado com um token administrativo definido no ambiente. A revisão requer ator e justificativa. O token simples é apenas para teste local; não substitui autenticação/roles de gestores.
- **Identidade laboral:** o identificador do colaborador é digitado no dispositivo. Este projeto não tem diretório/tenant de trabalhadores nem autorização corporativa; uma marcação assinada demonstra integridade técnica do evento, não prova vínculo empregatício ou presença.
- **Geofence opcional:** configure todos os valores `GEOFENCE_LATITUDE`, `GEOFENCE_LONGITUDE` e `GEOFENCE_RADIUS_METERS`. A aplicação só persiste classificação e faixa de precisão, nunca as coordenadas. GPS pode ser falsificado e o resultado nunca bloqueia o registro de jornada.

Exemplo PowerShell para ativar geofence e painel de revisão no processo local:

```powershell
$env:GEOFENCE_LATITUDE = "..."
$env:GEOFENCE_LONGITUDE = "..."
$env:GEOFENCE_RADIUS_METERS = "150"
$env:AUDIT_REVIEW_TOKEN = "use-um-segredo-local-de-teste"
npm start
```

O perímetro deve ser fornecido pelo responsável da operação, após análise de finalidade e privacidade. Não use o exemplo como valor real.

`FACE_DATA_DIR` pode apontar para uma pasta de dados local protegida diferente de `data`. Em produção, segredos e chaves exigem um gestor de segredos/KMS, rotação, controles de acesso e backups cifrados.

## Privacidade e limites

- As imagens da câmera são processadas no navegador e não são enviadas ao servidor nem persistidas.
- Os descritores faciais são cifrados no navegador com AES-GCM e uma chave AES efêmera encapsulada com RSA-OAEP antes do envio; o servidor mantém a chave privada apenas em memória. Isso é uma camada adicional de proteção do protótipo, não substitui TLS. Em produção, use HTTPS.
- Referências de colaborador, razões de exceção e payloads de auditoria são cifrados com a chave local do cofre no SQLite. O identificador de busca de cadastro usa HMAC; isso não anonimiza o dado biométrico.
- Os descritores faciais e o nome são criptografados em repouso com AES-256-GCM. A chave é criada localmente em `data/.vault-key`; mantenha a pasta `data` protegida e inclua-a em backup seguro se precisar preservar os cadastros. Definir `FACE_VAULT_KEY` (chave base64 de 32 bytes) permite fornecer uma chave externa.
- Cadastros e chave ficam em `data/`, pasta excluída do Git. A perda da chave torna os dados criptografados irrecuperáveis.
- O reconhecimento facial é probabilístico. O limiar é um compromisso entre falsas aceitações e rejeições, não uma garantia de identidade ou uma precisão certificada. Iluminação, câmera, pose e população podem alterar os resultados; valide o limiar com dados representativos antes de qualquer decisão de acesso.
- Este protótipo **não tem prova de vida nem detecção confiável de apresentação (foto/vídeo)**. Não o use para controlar portas, proteger ativos, substituir autenticação multifator ou tomar decisões de alto impacto. Para produção, é necessário um sistema especializado, teste independente de FAR/FRR, prova de vida, TLS, gestão segura de chaves, política de retenção/exclusão, controles de acesso e análise legal da LGPD.
- A geolocalização é pedida somente quando selecionada pelo usuário e disponível online. O resultado depende de valores de perímetro configurados no servidor.
- O servidor escuta somente em `127.0.0.1`. Não o exponha à rede. A permissão de câmera funciona em `localhost` ou em contexto HTTPS.
- A interface e a API não são um REP-P: não implementam artefatos/assinaturas/certificação exigidos nem foram validadas contra a Portaria MTP nº 671/2021 consolidada. Não declare conformidade com REP-P ou LGPD com base neste protótipo.
- Não há PAD/liveness, detecção confiável de câmera virtual, controle de voz embarcado, geofence autenticado, atestação de dispositivo, KMS/HSM, WORM, RBAC/MFA de gestor, nem exportação oficial de comprovante. Não prometa resistência a foto/vídeo, precisão, latência inferior a 1,5 s ou imutabilidade.
- A fila offline é uma contingência local de demonstração, não um registro juridicamente validado. Não limpe dados do navegador antes da sincronização e não use em produção.

## Testes

Execute `npm test` para validar normalização, descritores, integridade de eventos, assinatura ECDSA e geofence. Testes de API devem usar uma base de dados isolada; os eventos de produção demonstrativa são append-only.
