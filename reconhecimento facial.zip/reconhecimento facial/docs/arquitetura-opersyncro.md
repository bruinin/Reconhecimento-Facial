# OperSyncro — arquitetura de ponto, verificação facial e auditoria

**Status:** arquitetura proposta; vertical slice local demonstrativo implementado, sem certificação  
**Escopo:** captura e registro de ponto (Ponto de Contato) e análise de exceções (Auditor.IA)  
**Última revisão:** 2026-10-19

> Esta especificação não certifica conformidade com a legislação trabalhista ou com a LGPD, não valida um fornecedor biométrico e não constitui parecer jurídico. O protótipo local contém uma demonstração de fluxo de ponto e auditoria, mas não é um REP-P nem deve ser usado para registrar jornada oficial de trabalho.

## 1. Decisões de arquitetura

1. **O evento de jornada é separado da verificação facial.** Falha, indisponibilidade, dúvida ou recusa da biometria não descarta nem impede o registro do ponto. O evento é persistido como marcação e, se necessário, recebe um estado de verificação pendente para tratamento humano.
2. **Biometria é um sinal opcional, não um requisito universal.** Disponibilizar método alternativo equivalente e acessível, sem penalizar quem não pode ou não deseja concluir uma verificação facial. O empregador e seu jurídico devem definir a base legal adequada antes da coleta; não presumir que consentimento seja livre no vínculo de emprego.
3. **Imagens brutas não são persistidas nem transmitidas.** A inferência ocorre no dispositivo sempre que tecnicamente viável. Embeddings também são dados biométricos identificáveis: não são anônimos por simplesmente serem vetores.
4. **Sem galeria biométrica offline no dispositivo.** A fila offline contém marcações assinadas, não modelos ou templates de todos os trabalhadores. Verificação biométrica offline só é habilitada se uma plataforma nativa oferecer atestação local validada; caso contrário, a marcação segue como pendente ou usa alternativa não biométrica.
5. **A IA não decide consequência trabalhista.** Pontuação, geofence e sinais antifraude abrem uma exceção auditável, nunca uma falta, desconto, punição ou exclusão automática de marcação. A decisão sobre a jornada permanece revisável por pessoa autorizada e com possibilidade de contestação.
6. **“Imutável” significa evidência de adulteração, não impossibilidade absoluta.** Encadeamento criptográfico, assinaturas e armazenamento WORM dificultam e evidenciam mudanças; não protegem contra comprometimento simultâneo de chaves, aplicação e âncora externa.
7. **Metas de latência são hipóteses de desempenho.** A meta de 1,5 s deve ser definida por percentil, dispositivo, modelo, rede e condições de teste antes de ser aceita. Não é garantia universal em 4G.

## 2. Componentes e limites de confiança

```mermaid
flowchart LR
  subgraph Device["Dispositivo gerenciado / navegador"]
    UI["Ponto de Contato\ncâmera, acessibilidade, guia"]
    QC["Qualidade de captura\nluz, foco, enquadramento"]
    EDGE["Adaptador de inferência Edge\nmodelo versionado"]
    OUTBOX["Outbox offline cifrada\nsó eventos de ponto"]
    KEY["Keystore / chave do dispositivo"]
    UI --> QC --> EDGE
    UI --> OUTBOX
    KEY --> OUTBOX
  end

  subgraph Platform["Plataforma OperSyncro"]
    API["API Gateway\nTLS, autenticação, idempotência"]
    PUNCH["Serviço de Jornada\nregistro append-only"]
    VERIFY["Verificação / PAD\nassertion, score e versão"]
    AUDIT["Ledger de auditoria\nencadeamento + âncora"]
    RULES["Motor de exceções\nregras versionadas"]
    REP["Adaptador REP-P\ncomprovantes / arquivos"]
    REVIEW["Painel de revisão humana"]
    API --> PUNCH
    API --> VERIFY
    PUNCH --> AUDIT
    VERIFY --> AUDIT
    PUNCH --> RULES
    VERIFY --> RULES
    RULES --> REVIEW
    PUNCH --> REP
    RULES --> AUDIT
  end

  Device <-->|"TLS: marcações e assertions minimizadas"| API
  VERIFY -->|"resultado explicável e versionado"| REVIEW
```

### Responsabilidades

| Componente | Responsabilidade | Fora do escopo |
|---|---|---|
| Ponto de Contato | Permissão explícita da câmera, pré-visualização, qualidade de captura, fluxo acessível e emissão de marcação | Concluir identidade apenas porque existe um rosto no quadro |
| Adaptador Edge | Abstrair runtime/modelo, extrair características temporárias e devolver resultado tipado | Definir sozinho limiar de aprovação ou guardar imagens |
| Verificação/PAD | Comparar assertion de verificação e produzir sinais calibrados e versionados | Declarar “prova de vida perfeita” ou garantir ausência de fraude |
| Serviço de Jornada | Persistir cada evento e emitir comprovante; aceitar modo pendente/offline | Apagar/alterar evento original por decisão de score |
| Auditor.IA | Detectar padrões e priorizar exceções com razões codificadas e rastreáveis | Punir, descontar, bloquear jornada ou tomar decisão trabalhista autônoma |
| Painel do Gestor | Revisão humana com acesso mínimo, justificativa e contestação | Exibir templates, imagens ou geolocalização precisa por padrão |
| Adaptador REP-P | Gerar e manter artefatos exigidos pelo enquadramento técnico e regulatório aplicável | Substituir validação/certificação jurídica ou técnica |

## 3. Fluxo de captura e verificação

1. Autenticar o trabalhador e obter o contexto necessário à marcação. Mostrar aviso curto de finalidade, alternativa disponível e estado da câmera.
2. Pedir permissão de câmera somente quando o trabalhador inicia a ação. Usar HTTPS em produção, `getUserMedia`, estados explícitos de permissão negada/dispositivo ausente e desligar as tracks ao sair.
3. Avaliar enquadramento, foco, exposição, brilho e número de rostos no dispositivo. White balance e exposição dependem do hardware/navegador; usar APIs de capacidades quando disponíveis e nunca prometer controle uniforme. Orientação visual deve funcionar com leitores de tela, contraste, instrução textual e fluxo alternativo.
4. Capturar apenas o mínimo necessário. Inferência Edge por runtime atrás de uma interface substituível; escolher modelo após prova de conceito em Android, iOS e terminais-alvo. MediaPipe Face Detection localiza rostos, mas não é, por si só, modelo de reconhecimento. MobileFaceNet ou modelo equivalente é apenas candidato: avaliar licença, tamanho, desempenho e desempenho demográfico.
5. Se usar verificação central, preferir assertion assinada e vinculada a nonce de curta duração, finalidade e sessão. Não aceitar do cliente um score ou “identidade confirmada” sem prova verificável. Evitar enviar embedding reutilizável; se necessário, proteger transporte, armazenamento, chave e rotação, e submeter o desenho a revisão de privacidade e segurança.
6. Executar PAD (Presentation Attack Detection) como defesa em profundidade. Uma verificação facial suspeita **é rejeitada como prova de identidade** (`spoof_suspected`), sem liberar a autenticação facial; oferecer alternativa de verificação ou revisão. Um desafio de piscar/mover a cabeça pode ser inacessível e pode ser reproduzido; textura monocular, reflexos e sequência de frames não provam identidade nem derrotam máscaras ou injeção de câmera.
7. Construir um evento de ponto independentemente do resultado biométrico. Resultado inconclusivo, sem câmera, sem rede, score baixo ou PAD suspeito cria uma marcação com estado `review_required` e um aviso neutro, sem impedir a emissão do comprovante. A rejeição se aplica à tentativa biométrica, **não ao registro de jornada**.
8. Mostrar ao trabalhador o resultado operacional, um identificador de comprovante e como corrigir/contestar. Não exibir score sensível desnecessariamente.

### Sinais de qualidade da captura

Aplicar regras pré-captura configuráveis e observáveis, sem correção silenciosa que mude o rosto:

- `face_count`: deve ser um rosto para a tentativa biométrica; caso contrário, oferecer nova tentativa ou método alternativo.
- `face_size`, `pose`, `blur`, `exposure`, `illumination`: limites calibrados por dispositivo. Exibir orientação clara; não converter qualidade ruim em suspeita de fraude.
- `camera_integrity`: registrar apenas sinal de risco e versão/atestado disponível. Detecção de câmera virtual não é universal nem prova conclusiva.
- Registrar métricas agregadas de qualidade, não frames, salvo desenho específico aprovado, base legal, retenção curta e controles adicionais.

### Defesa contra foto impressa e replay em tela

Uma webcam RGB convencional **não consegue garantir** a rejeição de todas as fotografias, reproduções em telas, máscaras ou ataques de injeção. A meta verificável é avaliar e reduzir ataques conhecidos num protocolo publicado; nunca anunciar “à prova de foto/tela” sem evidência independente, escopo de ataques e taxas medidas. A aprovação do PAD indica risco estimado sob condições testadas, não prova absoluta de uma pessoa viva.

Para bloquear a tentativa biométrica suspeita, sem bloquear o ponto:

1. **Desafio fresco e vinculado à sessão:** quando o produto exigir desafio ativo, gerar nonce aleatório de uso único, com validade curta e ações imprevisíveis escolhidas no servidor. Vincular resultado, sessão e sequência capturada ao nonce; rejeitar nonce repetido, expirado, fora de ordem ou sem assinatura válida. Não considerar uma ação coreografada fixa (por exemplo, sempre piscar) como prova suficiente: vídeo pré-gravado pode reproduzi-la.
2. **PAD passivo + ativo avaliado:** usar um PAD especializado, com suporte a sequências temporais e saída `bona_fide`, `attack` ou `inconclusive`. Avaliar separadamente impressões, telas de diferentes tecnologias/brilho, replay, máscaras e artefatos. Reflexos oculares, moiré, textura ou profundidade monocular são sinais do modelo, não regras determinísticas de rejeição.
3. **Sensor/plataforma mais confiáveis quando o risco exigir:** preferir terminal gerenciado com sensor de profundidade/IR ou hardware biométrico certificado e caminho de captura atestado. Web `getUserMedia` sozinho não atesta que os frames vieram da câmera física: câmera virtual, dispositivo comprometido e injeção podem contornar o fluxo. Se não houver atestação, registrar essa limitação e não elevar o nível de garantia.
4. **Decisão fail-closed para a biometria:** `attack`, desafio inválido, PAD indisponível ou inconclusivo nunca concede verificação facial. Aplicar limites de tentativas e backoff à tentativa biométrica, evitar mensagens que revelem limiares e acionar alternativa acessível ou revisão. Essa rejeição não pode suprimir a marcação de ponto nem causar punição automática.
5. **Sem retenção de evidência bruta por padrão:** avaliar no dispositivo e descartar frames imediatamente após a inferência. Não guardar imagens de ataques para “auditoria” por conveniência. Qualquer exceção requer finalidade/base legal específicas, avaliação de necessidade, transparência, acesso restrito, retenção curta e descarte verificável.
6. **Sem embeddings offline compartilhados:** não colocar templates biométricos numa fila sincronizável ou cache de dispositivos. A fila offline contém apenas a marcação mínima e sua assinatura; a tentativa de identidade fica pendente quando não houver um verificador local confiável.

Contrato conceitual do resultado PAD:

```json
{
  "status": "attack",
  "attackClass": "print_or_screen_replay",
  "challengeRef": "nonce opaco de uso único",
  "modelVersion": "pad/provider/version",
  "policyVersion": "pad-policy/version"
}
```

`attackClass` é opcional e só deve ser preenchido se o fornecedor suportar a classificação com validação adequada. Não enviar imagem, embedding, score bruto ou sequência de vídeo nesse evento de auditoria. Para a aplicação, `attack` resulta em `spoof_suspected`, `inconclusive` em `review_required` e nenhum deles impede a criação do evento de jornada.

#### Testes e critérios para liberar o PAD

- Definir previamente o protocolo, ataques cobertos, ambiente, hardware, versão do sensor, população e limiar; usar laboratório independente e conjunto de teste separado dos dados de treino/ajuste.
- Reportar APCER/BPCER e intervalos de confiança por classe de apresentação e dispositivo. Fixar limites de aceitação com Segurança, Produto e Jurídico antes do teste; “acurácia média” isolada não é critério suficiente.
- Testar fotografias impressas de diferentes qualidades, tamanhos, acabamentos e distâncias; replay em mais de uma família de tela e condições de brilho/ângulo; vídeo pré-gravado; tentativa de repetir desafio; câmera virtual/injeção; replay de assertions; sensor coberto ou desconectado; ausência de luz, foco e rede.
- Incluir usuários genuínos e condições diversas para medir BPCER, acessibilidade e impacto diferencial; validar o caminho alternativo sem câmera.
- Testar o sistema completo, não apenas o modelo: origem e frescor do frame, nonce, assinatura, TLS, prevenção de replay, política de limitação e comportamento seguro quando PAD/servidor falhar.
- Bloquear a autenticação biométrica para tentativa classificada como ataque; manter o registro de jornada, comprovante, trilha de revisão e alternativa. Não validar apenas a mensagem de erro visual.
- Repetir os testes após mudança de modelo, câmera, runtime, dispositivo, política ou limiar. Monitorar regressões sem coletar biometria adicional sem justificativa.

Usar a [ISO/IEC 30107-3](https://www.iso.org/standard/67381.html) como referência para avaliação e reporte de PAD (ela não padroniza uma defesa nem substitui uma avaliação de segurança do sistema). Consultar também os [resultados e condições do NIST FATE PAD](https://pages.nist.gov/frvt/html/frvt_pad.html); o estado da avaliação/submissão indicado pelo NIST pode mudar. Não inferir que um modelo passou nesses testes sem confirmar a identidade da submissão, protocolo e relatório correspondente.

## 4. Contrato dos eventos

### 4.1 Marcação

Endpoint conceitual:

```http
POST /v1/time-events
Authorization: Bearer <access-token>
Idempotency-Key: <UUID criado uma vez no dispositivo>
Content-Type: application/json
```

```json
{
  "eventId": "UUID",
  "employeeRef": "referência opaca autorizada",
  "eventType": "clock_in",
  "deviceRef": "identificador pseudônimo rotacionável",
  "deviceSequence": 104,
  "occurredAtDevice": "2026-10-19T13:00:00-03:00",
  "timeQuality": "offline-estimated",
  "verification": {
    "method": "face",
    "status": "spoof_suspected",
    "modelVersion": "provider/model/version",
    "padModelVersion": "provider/pad/version",
    "assertionRef": "referência curta ou nula"
  },
  "location": {
    "geofenceResult": "inside",
    "accuracyBucketMeters": "10-50"
  }
}
```

O esquema é ilustrativo. `occurredAtDevice` é declarado pelo dispositivo e **não** é um relógio confiável. O servidor acrescenta `receivedAtServer`, mantém ambos sem sobrescrever evidência original e marca a qualidade temporal. A posição bruta não é padrão: reter apenas o resultado do geofence e uma faixa de precisão, quando isso for necessário e juridicamente aprovado. Não incluir embedding, frame, nome completo, endereço IP ou user-agent detalhado nos logs de aplicação.

Resposta online:

```json
{
  "eventId": "UUID",
  "receiptId": "identificador de comprovante",
  "recordedAtServer": "2026-10-19T16:00:00Z",
  "verificationStatus": "review_required",
  "receiptSignature": "assinatura verificável do comprovante"
}
```

Resposta offline: o app guarda o evento na outbox e emite comprovante provisório com `syncStatus: "pending"`. Após sincronização, o servidor devolve recibo definitivo e preserva o timestamp declarado, timestamp de recepção e incerteza. **Não** reescrever silenciosamente o horário original nem marcar evento offline como horário de servidor.

### 4.2 Tipos e estados

- Tipos de marcação devem mapear a política de jornada aplicável, não ser inferidos pelo rosto.
- Estado da marcação: `recorded`, `provisional_offline`, `corrected` (por novo evento de ajuste, nunca sobrescrita).
- Estado de verificação: `not_requested`, `verified`, `inconclusive`, `unavailable`, `spoof_suspected`, `review_required`.
- Estado da revisão: `open`, `under_review`, `resolved`, `contested`; cada transição registra ator, horário, regra e justificativa.
- Ausência de resultado biométrico nunca altera `recorded` para rejeitado.

## 5. Auditor.IA e gestão de exceções

O motor combina regras determinísticas e, se justificado, modelos de anomalia. Cada regra e modelo tem `policyVersion`, `modelVersion`, janela temporal e razão legível. Sinais possíveis incluem falha de PAD, assertion expirada/reutilizada, mudança de dispositivo não cadastrada, geofence inconclusivo, qualidade insuficiente e repetição anormal de tentativas. “Anomalia” significa prioridade de revisão, não fraude comprovada.

| Sinal | Estado do ponto | Tratamento |
|---|---|---|
| Verificação forte e válida | Registrado | Comprovante normal; registrar versão do verificador |
| Confiança na zona de incerteza | Registrado | Criar exceção; revisão humana; aceitar contestação |
| Score abaixo do limiar, PAD inconclusivo ou câmera indisponível | Registrado, verificação pendente | Método alternativo e fila de revisão; nunca bloquear a marcação |
| PAD classifica foto/tela como ataque | Registrado, verificação `spoof_suspected` | Rejeitar esta tentativa biométrica, criar exceção minimizada e oferecer alternativa; não concluir identidade nem bloquear o ponto |
| Geofence fora/indisponível | Registrado | Se necessário, sinalizar exceção; localização não é prova isolada de presença |
| Serviço offline | Provisório localmente | Outbox cifrada, sincronização idempotente e auditoria posterior |

Limiares não devem ser escolhidos por intuição ou pelo exemplo de outro fornecedor. Medir FAR/FRR por condições de captura e grupos relevantes; medir APCER/BPCER para PAD e ataques cobertos; publicar intervalo de confiança, amostra, versões e política de operação. Teste independente deve incluir câmera virtual/injeção, replay em diferentes telas, fotografia impressa, máscara/artefato e iluminação/pose adversas. Mesmo resultados positivos só descrevem os ataques e a população testados.

O painel de exceções deve mostrar o motivo codificado, a evidência mínima, versão de regra, histórico de revisão e controles de correção. Não deve permitir busca biométrica em lote, exportação de templates, ranking de trabalhadores ou perfilamento oculto. Aplicar segregação de funções, acesso por finalidade, auditoria de consultas e prazo de retenção.

## 6. Geofence e recursos opcionais

- O geofence é um indicador sujeito a erro de GPS, indoor, spoofing e permissão negada; não demonstra sozinho que a pessoa trabalhou ou não trabalhou naquele local.
- Pedir localização no momento da marcação, justificar finalidade e oferecer alternativa quando indisponível. A permissão deve ser contextual e revogável.
- Calcular o resultado na borda quando possível; guardar `inside/outside/unknown`, versão do perímetro e faixa de precisão. Coordenada precisa só por exceção aprovada e com prazo curto documentado.
- Não coletar localização contínua ou em segundo plano para esta finalidade.
- Comando de voz é opcional, não fator de identidade. Reconhecimento de fala embarcado deve operar sem gravar áudio; sempre fornecer controle visual/tátil equivalente. Acessibilidade não depende de câmera, voz ou localização.

## 7. Modo offline

1. Usar outbox cifrada no armazenamento protegido do sistema operacional em aplicativo nativo. Em PWA, IndexedDB e WebCrypto oferecem proteção limitada: script comprometido no mesmo origin pode acessar dados após desbloqueio; não tratar como keystore hardware.
2. Guardar somente evento mínimo, identificador de idempotência, sequência por dispositivo, assinatura e evidência temporal. Não baixar roster biométrico ou galeria de embeddings para autenticar offline.
3. Assinar evento com chave de dispositivo não exportável e vinculada ao usuário/dispositivo quando a plataforma suportar presença do usuário e atestação. Se isso não existir, rotular claramente a força menor da evidência.
4. Sincronizar com `eventId`/`Idempotency-Key`; servidor valida assinatura, sequência, janela de atraso e duplicatas. Repetições são idempotentes. Conflitos preservam ambos os eventos e encaminham à revisão.
5. Não afirmar que timestamp de dispositivo comprometido é seguro. Guardar monotonic counter/tempo local apenas como sinal; comparar lacunas, drift e horário de recepção sem apagar a hora declarada.
6. Não guardar imagem, embedding ou dados biométricos em fila offline. Se a operação exigir biometria sem conexão, tratar como decisão de produto e risco distinta, com aprovação de segurança, jurídico e proteção de dados.
7. Em perda/roubo do aparelho, revogar credencial do dispositivo, limitar janela/quantidade de eventos offline e executar limpeza remota quando o dispositivo voltar a conectar.

## 8. Integridade, segurança e privacidade

### Integridade de jornada

- Criar evento append-only com UUID, tenant, sequência, `receivedAtServer`, hora declarada, origem, estado e hash do evento canônico.
- Encadear hashes por partição de auditoria e assinar raízes periódicas com chave em KMS/HSM; replicar raízes para armazenamento com retenção bloqueada (WORM) sob administração separada.
- Correções são novos eventos vinculados ao original, com ator, justificativa e autorização; nunca UPDATE/DELETE silencioso da marcação.
- Assinar comprovante verificável e preservar trilha para exportação e reconciliação.
- Monitorar relógios de serviço, acesso privilegiado, falhas de assinatura, lacunas de sequência e operações administrativas.
- Hash-chain isolada no mesmo banco não é prova contra administrador privilegiado. Validar a cadeia de custódia e formatos junto ao responsável técnico/jurídico pelo REP-P.

### Dados e controles

| Dado | Classificação / risco | Controle e minimização |
|---|---|---|
| Imagem/vídeo facial | Biométrico, altamente sensível | Processar em memória no dispositivo; não registrar, cachear ou enviar |
| Embedding/template | Dado biométrico sensível quando vinculado/identificável | Preferir não centralizar; se indispensável, criptografia de envelope, chaves separadas, acesso segregado, rotação, descarte e teste de reidentificação |
| Nome/identificador laboral | Dado pessoal | Referência opaca em eventos, controle por tenant e menor privilégio |
| Localização | Dado pessoal contextual | Resultado de geofence/faixa por padrão, sem rastreamento contínuo |
| Rede/dispositivo | Dado pessoal potencial | Identificador pseudônimo; retenção e granularidade limitadas; evitar logs duplicados |
| Score/razão antifraude | Perfil inferido que pode afetar o trabalhador | Acesso restrito, explicabilidade, contestação, revisão humana e retenção limitada |
| Jornada/comprovante | Registro laboral | Append-only, exportação auditável, correções rastreáveis e política de retenção aprovada |

Requisitos mínimos: TLS atual, criptografia em repouso e de envelope; KMS/HSM com rotação e separação de deveres; secrets fora do código; controle de acesso por tenant/função; MFA para gestores; rate limiting; defesa contra replay; validação de entrada; logging sem dados biométricos; monitoramento de abuso; backup cifrado e exercícios de restauração; revisão de dependências/modelos; teste de intrusão; resposta a incidente e revogação de credenciais.

Fazer avaliação de impacto à proteção de dados (RIPD) antes de piloto, com encarregado/jurídico e representação apropriada dos trabalhadores. Documentar finalidade, necessidade, proporcionalidade, base legal específica, transparência, retenção, direitos dos titulares, operadores/suboperadores, transferências internacionais, resposta a incidentes e alternativa não biométrica. Avaliar vieses e efeitos adversos por grupos. Definir procedimento para acesso/correção/eliminação quando aplicável e retenção legal justificada. Não usar consentimento como atalho automático em contexto de subordinação trabalhista.

## 9. REP-P e validação legal

“REP-P” é uma categoria regulada de registrador eletrônico de ponto, não uma etiqueta de arquitetura. Antes de produção, confirmar com especialista trabalhista e responsável técnico:

- versão consolidada e aplicabilidade da Portaria MTP nº 671/2021 e alterações vigentes no momento do lançamento;
- requisitos e registros/certificados aplicáveis ao programa e ao fornecedor, inclusive comprovantes, arquivos e formatos oficiais exigidos;
- fluxo de emissão, guarda, acesso, correção e apresentação das marcações, espelho e arquivos fiscais conforme o enquadramento;
- preservação e disponibilidade de registros para fiscalização e trabalhador;
- política de ponto, acordo/Convenção Coletiva, tratamento de exceções e procedimento de contingência;
- papéis de controlador/operador, fundamento do tratamento biométrico e geográfico, RIPD, transparência e exercício dos direitos na LGPD.

Não afirmar “100% conforme MTE/LGPD” até parecer formal e testes de conformidade contra os textos oficiais consolidados. Revalidar normas, guias e contratos em cada mudança material.

## 10. Metas, SLOs e critérios de aceite

O alvo `<1,5 s` deve ser medido do início da captura ao resultado visível, excluindo apenas operações claramente delimitadas e documentadas. O produto deve definir SLOs por perfil de dispositivo/rede; proposta inicial de experimento:

| Métrica | Critério de experimento |
|---|---|
| Latência online | p95 ≤ 1,5 s em matriz publicada de dispositivos e 4G; também reportar p50/p99 e falhas/timeouts |
| Latência Edge | Medir separadamente captura, detecção, landmarks, embedding e PAD; aquecimento do modelo reportado |
| Disponibilidade offline | Criar e recuperar evento provisório sem rede; verificar cifragem, reinício do app e armazenamento cheio |
| Consistência | Duplicar/reordenar sincronização; preservar um evento por idempotency key e manter proveniência |
| Identificação/verificação | Reportar FAR/FRR com intervalos de confiança e por condições/grupos; sem threshold “universal” |
| PAD | Reportar APCER/BPCER por categoria de ataque testada; documentar ataques não cobertos |
| Integridade | Detectar alteração, truncamento, replay, chave expirada e sequência faltante; verificar assinatura do recibo |
| Acessibilidade | Concluir fluxo sem câmera, sem voz e sem localização; testar leitor de tela, teclado, contraste e mobilidade |
| Privacidade | Inspecionar tráfego, cache, logs, analytics e backups; comprovar ausência de frames e embeddings não autorizados |
| REP-P | Testar artefatos e procedimentos com especialista e suíte aplicável antes de declaração de conformidade |

A latência de reconhecimento é apenas uma parte da jornada. Se captura, autorização, rede e servidor não cumprirem o limite medido, o registro de ponto continua disponível e recebe status operacional adequado.

## 11. Proposta de contratos internos

Interfaces de domínio (nomes ilustrativos, independentes de framework):

```text
CaptureAdapter.start(constraints) -> CameraSession
CaptureAdapter.assessQuality(frame) -> QualityResult
CaptureAdapter.capture() -> EphemeralFrame
FaceVerifier.verify(frame, challenge, modelPolicy) -> VerificationResult
PresentationAttackDetector.assess(frames, challenge) -> PadResult
TimeEventService.record(command) -> Recorded | ProvisionalOffline
Outbox.enqueue(signedEvent) -> QueueReceipt
Outbox.sync(connectivity) -> SyncReport
AuditLedger.append(event, provenance) -> SignedAuditReceipt
ExceptionEngine.evaluate(event, verification, policyVersion) -> ReviewDecision
```

Todos os erros devem ser tipados (permissão, dispositivo, qualidade, modelo, rede, assinatura, política). A interface de captura não deve lançar `VerificationFailed` como `TimeEventRejected`: são domínios independentes.

## 12. Plano incremental de entrega

1. **Descoberta e governança:** definir política de jornada, base legal, controladores/operadores, RIPD, retenção, alternativa não biométrica, população e dispositivos-alvo.
2. **Núcleo de jornada sem biometria:** eventos append-only, comprovante, correções como novos eventos, API idempotente, modo de contingência e testes de exportação REP-P.
3. **Ponto de Contato online:** câmera opt-in, avaliação de qualidade, accessibility, fluxo de marcação independente e sinais de verificação em sandbox.
4. **Avaliação biométrica/PAD:** seleção de fornecedor/modelo sob licença, protocolo independente de FAR/FRR/APCER/BPCER, matriz de hardware e revisão de segurança/viés. Sem produção enquanto limiares não forem aprovados.
5. **Auditor.IA e revisão humana:** regras explicáveis/versionadas, painel de exceções, controle de acesso e contestação; começar com regras determinísticas antes de ML.
6. **Offline:** aplicativo e keystore de plataforma aprovados, fila limitada, assinatura, sincronização idempotente, testes de adulteração, perda de dispositivo e relógio divergente.
7. **Piloto controlado:** grupos/dispositivos diversos, operação paralela com método alternativo, monitoramento de falsos positivos, pesquisa de impacto e critérios de interrupção.
8. **Go-live:** evidência jurídica, técnica, de segurança, desempenho e privacidade revisada e assinada pelos responsáveis. Retorno ao método não biométrico continua disponível.

## 13. Critérios de não lançamento

Não lançar se qualquer ponto for verdadeiro:

- a única forma de registrar ponto for biométrica, geográfica, por voz ou online;
- uma falha de modelo, PAD, rede, GPS ou fornecedor excluir ou apagar uma marcação;
- não houver procedimento de correção e contestação com revisão humana;
- não houver base legal e RIPD revisados para cada tratamento sensível;
- imagens ou templates forem coletados além do necessário, sem retenção e descarte verificáveis;
- limiares não tiverem sido testados independentemente na população e nos dispositivos reais;
- o PAD não tiver avaliação independente contra fotos impressas, replay em telas e ataques de injeção nos dispositivos efetivamente suportados, ou não rejeitar falhas de vivacidade sem impedir o registro do ponto;
- a solução alegar prova de vida infalível, precisão garantida, imutabilidade absoluta ou conformidade certificada sem evidência;
- o formato, certificação ou processo REP-P aplicável não tiver sido validado para a versão de lançamento.

## 14. Fontes primárias para validação

Consultar sempre a versão vigente e alterações posteriores, com assessoria qualificada:

- [Lei nº 13.709/2018 — Lei Geral de Proteção de Dados (Planalto)](https://www.planalto.gov.br/ccivil_03/_ato2015-2018/2018/lei/l13709.htm) — especialmente definições, princípios, dados sensíveis e hipóteses de tratamento.
- [Ministério do Trabalho e Emprego](https://www.gov.br/trabalho-e-emprego/pt-br) — localizar a Portaria MTP nº 671/2021 consolidada, alterações e orientações oficiais sobre registro eletrônico de ponto (REP).
- [Diário Oficial da União](https://www.in.gov.br/) — publicação original e alterações normativas da Portaria MTP nº 671/2021.
- [Autoridade Nacional de Proteção de Dados](https://www.gov.br/anpd/pt-br) — regulamentos, guias e orientações atuais para agentes de tratamento, dados sensíveis, incidentes e RIPD.

Esta lista é um ponto de partida para verificação, não uma conclusão de conformidade.

## 15. Estado da implementação demonstrativa

O workspace implementa somente uma fatia vertical local para experimentar contratos e salvaguardas:

| Área | Implementado | Limite que permanece |
|---|---|---|
| Captura | Câmera sob ação explícita; verificação de quantidade de rostos, tamanho e brilho; tracks encerradas ao fim da operação | Sem balanço de branco uniforme, estimativa validada de foco/desfoque, compatibilidade multiplataforma certificada ou meta de latência medida |
| Transporte biométrico | Três descritores cifrados no navegador com AES-GCM e chave AES envolvida em RSA-OAEP; uma assertion opaca, curta e de uso único vincula uma correspondência facial à referência declarada; o servidor não confia no estado biométrico autodeclarado no evento de ponto | Assertion em memória do processo e não atestada; sem PAD; mesmo uma correspondência facial válida é rebaixada para `review_required`; não prova vínculo com cadastro laboral nem origem física da câmera |
| Jornada | Tipos básicos de marcação, timestamp declarado pelo dispositivo, recepção no servidor e política de falha aberta para a marcação | Não substitui um sistema de jornada e seu comprovante não é documento REP-P |
| Identidade laboral | Campo manual `workerRef` no protótipo | Sem diretório de trabalhadores, tenant, autenticação corporativa ou autorização de dispositivo; não prova vínculo laboral nem presença física |
| Contingência offline | App-shell cacheado, fila cifrada em IndexedDB, chave ECDSA não exportável via WebCrypto, sequência local e sincronização idempotente | Sem keystore de hardware, atestação, política de retenção/limite aprovada, proteção contra script comprometido no origin ou garantia do relógio do dispositivo |
| Integridade | Tabelas append-only por triggers, campos sensíveis e payloads de auditoria cifrados, hash chain e HMAC com chave derivada do cofre local; verificação administrativa da cadeia e do vínculo entre ledger e registros | Banco e chave no mesmo host; sem KMS/HSM, âncora externa, WORM ou recibo publicamente verificável |
| Auditor.IA | Regras determinísticas para estado biométrico inconclusivo/indisponível, PAD não configurado, conflito de sequência e geofence desconhecido/fora; painel tokenizado com justificativa e ator | Token local não equivale a identidade/roles/MFA; sem modelo de anomalia, decisão autônoma ou evidência de fraude |
| Geofence | Opt-in por marcação; classificação server-side com banda de precisão; coordenadas não persistidas | GPS pode ser falsificado; sem configuração, o resultado é `unknown`; não usar como prova isolada nem bloquear ponto |
| Voz | Controle tátil e fluxo convencional acessíveis | Comando de voz embarcado não implementado; APIs do navegador podem processar áudio externamente |
| REP-P/LGPD | Limites e plano de validação documentados | Sem parecer jurídico, RIPD aprovado, certificação, pacote fiscal, retenção aprovada ou declaração de conformidade |

Configuração local opcional:

- `FACE_DATA_DIR`: pasta local do SQLite e do cofre.
- `AUDIT_REVIEW_TOKEN`: habilita o painel demonstrativo de exceções; use apenas em máquina local e defina um segredo de teste.
- `GEOFENCE_LATITUDE`, `GEOFENCE_LONGITUDE` e `GEOFENCE_RADIUS_METERS`: habilitam avaliação aproximada do perímetro. Configure os três valores em conjunto.

O cliente não armazena coordenadas ou descritores na fila offline. A posição, quando autorizada, só é enviada em memória durante uma tentativa online; se a sincronização falhar, a marcação mantém geofence `unknown`. A chave de assinatura WebCrypto é armazenada como `CryptoKey` no IndexedDB e não equivale a chave atestada em hardware.

Antes de substituir qualquer etapa do sistema atual de jornada, concluir os critérios de não lançamento da seção 13, revisão de segurança independente, testes de impacto/viés, validação jurídica e integração com a implementação REP aplicável. A falha de reconhecimento/PAD/localização/rede continua sem apagar nem bloquear a marcação.
