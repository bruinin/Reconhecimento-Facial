(() => {
  const video = document.getElementById('camera');
  const placeholder = document.getElementById('camera-placeholder');
  const cameraState = document.getElementById('camera-state');
  const cameraTitle = document.getElementById('camera-title');
  const faceGuide = document.querySelector('.face-guide');
  const feedback = document.getElementById('feedback');
  const captureLabel = document.getElementById('capture-label');
  const captureCount = document.getElementById('capture-count');
  const progressBar = document.getElementById('progress-bar');
  const loginForm = document.getElementById('login-form');
  const registerForm = document.getElementById('register-form');
  const punchForm = document.getElementById('punch-form');
  const auditForm = document.getElementById('audit-form');
  const signedIn = document.getElementById('signed-in');
  const toast = document.getElementById('toast');
  const modelsUrl = '/models';
  let stream = null;
  let cameraStartPromise = null;
  let cameraRequestId = 0;
  let modelsReady = false;
  let busy = false;
  let toastTimeout;

  function setFeedback(message, type = '') {
    feedback.textContent = message;
    feedback.className = `feedback${type ? ` ${type}` : ''}`;
  }

  function showToast(message, type = '') {
    toast.textContent = message;
    toast.className = `toast${type ? ` ${type}` : ''}`;
    toast.hidden = false;
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => { toast.hidden = true; }, 5000);
  }

  function updateProgress(count, label) {
    captureLabel.textContent = label;
    captureCount.textContent = `${count} / 3`;
    progressBar.classList.remove('progress-0', 'progress-1', 'progress-2', 'progress-3');
    progressBar.classList.add(`progress-${count}`);
  }

  function assessFrameQuality(face) {
    const box = face.detection.box;
    if (box.width < video.videoWidth * 0.2 || box.height < video.videoHeight * 0.2) {
      faceGuide.classList.add('quality-bad');
      faceGuide.classList.remove('quality-good');
      throw new Error('Aproxime um pouco o rosto e mantenha-o dentro do guia.');
    }

    const canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 48;
    const context = canvas.getContext('2d', { willReadFrequently: true });
    context.drawImage(video, 0, 0, canvas.width, canvas.height);
    const pixels = context.getImageData(0, 0, canvas.width, canvas.height).data;
    let brightness = 0;
    let clipped = 0;
    for (let index = 0; index < pixels.length; index += 4) {
      const luminance = pixels[index] * 0.2126 + pixels[index + 1] * 0.7152 + pixels[index + 2] * 0.0722;
      brightness += luminance;
      if (luminance < 12 || luminance > 245) clipped += 1;
    }
    const pixelCount = pixels.length / 4;
    const average = brightness / pixelCount;
    if (average < 38) {
      faceGuide.classList.add('quality-bad');
      faceGuide.classList.remove('quality-good');
      throw new Error('A imagem está escura. Procure uma iluminação frontal melhor.');
    }
    if (average > 220 || clipped / pixelCount > 0.4) {
      faceGuide.classList.add('quality-bad');
      faceGuide.classList.remove('quality-good');
      throw new Error('A imagem está muito clara. Evite luz forte diretamente na câmera.');
    }
    faceGuide.classList.add('quality-good');
    faceGuide.classList.remove('quality-bad');
  }

  async function ensureModels() {
    if (modelsReady) return;
    const faceApi = window.faceapi;
    if (!faceApi) {
      throw new Error('A biblioteca facial não foi carregada. Confirme que o servidor está ativo e recarregue a página.');
    }
    setFeedback('Carregando modelos de reconhecimento no navegador…');
    await Promise.all([
      faceApi.nets.ssdMobilenetv1.loadFromUri(modelsUrl),
      faceApi.nets.faceLandmark68Net.loadFromUri(modelsUrl),
      faceApi.nets.faceRecognitionNet.loadFromUri(modelsUrl),
    ]);
    modelsReady = true;
  }

  async function ensureCamera() {
    if (stream?.getTracks().some((track) => track.readyState === 'live')) return;
    if (cameraStartPromise) return cameraStartPromise;
    if (!navigator.mediaDevices?.getUserMedia) {
      throw new Error('Este navegador não oferece acesso seguro à câmera. Abra o aplicativo em http://localhost.');
    }
    const requestId = ++cameraRequestId;
    const startPromise = (async () => {
      const nextStream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } },
      });
      if (requestId !== cameraRequestId) {
        nextStream.getTracks().forEach((track) => track.stop());
        throw new Error('A câmera foi desligada ao sair do modo facial.');
      }
      stream = nextStream;
      video.srcObject = stream;
      await new Promise((resolve) => {
        if (video.readyState >= HTMLMediaElement.HAVE_METADATA) {
          resolve();
        } else {
          video.addEventListener('loadedmetadata', resolve, { once: true });
        }
      });
      await video.play();
      placeholder.hidden = true;
      cameraState.classList.add('active');
      cameraState.innerHTML = '<span class="status-dot"></span> CÂMERA ATIVA';
      cameraTitle.textContent = 'Posicione seu rosto no guia';
    })();
    cameraStartPromise = startPromise;
    try {
      await startPromise;
    } catch (error) {
      if (requestId === cameraRequestId && stream) stopCamera();
      throw error;
    } finally {
      if (cameraStartPromise === startPromise) cameraStartPromise = null;
    }
  }

  async function captureDescriptors() {
    await ensureCamera();
    await ensureModels();
    const faceApi = window.faceapi;
    const descriptors = [];
    cameraState.classList.add('capturing');
    cameraState.innerHTML = '<span class="status-dot"></span> CAPTURANDO';
    updateProgress(0, 'Mantenha o rosto centralizado');

    try {
      for (let index = 0; index < 3; index += 1) {
        if (index > 0) await new Promise((resolve) => setTimeout(resolve, 450));
        const faces = await faceApi
          .detectAllFaces(video, new faceApi.SsdMobilenetv1Options({ minConfidence: 0.65 }))
          .withFaceLandmarks()
          .withFaceDescriptors();

        if (faces.length !== 1) {
          throw new Error(faces.length === 0
            ? 'Não encontramos um rosto. Melhore a iluminação e centralize o rosto no guia.'
            : 'Detectamos mais de um rosto. Deixe apenas uma pessoa diante da câmera.');
        }
        assessFrameQuality(faces[0]);
        descriptors.push(Array.from(faces[0].descriptor));
        updateProgress(index + 1, 'Capturas faciais concluídas');
      }
    } finally {
      if (stream?.getTracks().some((track) => track.readyState === 'live')) {
        cameraState.classList.remove('capturing');
        cameraState.classList.add('active');
        cameraState.innerHTML = '<span class="status-dot"></span> CÂMERA ATIVA';
      }
    }
    return descriptors;
  }

  function toBase64Url(bytes) {
    let binary = '';
    for (const byte of bytes) binary += String.fromCharCode(byte);
    return btoa(binary).replace(/\+/gu, '-').replace(/\//gu, '_').replace(/=+$/u, '');
  }

  async function encryptDescriptors(descriptors) {
    const response = await fetch('/api/biometric/key', { cache: 'no-store' });
    if (!response.ok) throw new Error('Não foi possível obter a chave temporária de proteção biométrica.');
    const biometricTransportKey = await response.json();
    const publicKey = await crypto.subtle.importKey(
      'jwk',
      {
        ...biometricTransportKey.publicKey,
        alg: 'RSA-OAEP-256',
        ext: true,
        key_ops: ['encrypt'],
      },
      { name: 'RSA-OAEP', hash: 'SHA-256' },
      false,
      ['encrypt']
    );
    const aesKey = crypto.getRandomValues(new Uint8Array(32));
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encryptionKey = await crypto.subtle.importKey('raw', aesKey, 'AES-GCM', false, ['encrypt']);
    const ciphertext = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      encryptionKey,
      new TextEncoder().encode(JSON.stringify(descriptors))
    );
    const wrappedKey = await crypto.subtle.encrypt({ name: 'RSA-OAEP' }, publicKey, aesKey);
    return {
      keyId: biometricTransportKey.keyId,
      wrappedKey: toBase64Url(new Uint8Array(wrappedKey)),
      iv: toBase64Url(iv),
      ciphertext: toBase64Url(new Uint8Array(ciphertext)),
    };
  }

  async function postJson(url, body) {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify(body),
    });
    const result = await response.json();
    if (!response.ok) {
      const error = new Error(result.error || 'Não foi possível concluir a solicitação.');
      error.status = response.status;
      throw error;
    }
    return result;
  }

  async function submitForm(form, button, endpoint) {
    if (busy) return;
    busy = true;
    button.disabled = true;
    const buttonText = button.querySelector('span:first-child');
    const originalText = buttonText.textContent;
    buttonText.textContent = 'Aguarde…';
    setFeedback('Prepare-se para as três capturas.');
    updateProgress(0, 'Três capturas ajudam a reduzir erros');

    try {
      const name = new FormData(form).get('name');
      const descriptors = await captureDescriptors();
      const descriptorEnvelope = await encryptDescriptors(descriptors);
      const result = await postJson(endpoint, { name, descriptorEnvelope });
      updateProgress(3, 'Capturas faciais concluídas');
      setFeedback(result.message, 'success');
      if (endpoint === '/api/login') await refreshSession();
      else showToast(result.message);
    } catch (error) {
      setFeedback(error.message, 'error');
      updateProgress(0, 'Três capturas ajudam a reduzir erros');
    } finally {
      busy = false;
      button.disabled = false;
      buttonText.textContent = originalText;
    }
  }

  function selectTab(tab) {
    const registering = tab === 'register';
    const punching = tab === 'punch';
    const auditing = tab === 'audit';
    loginForm.hidden = registering;
    registerForm.hidden = !registering;
    punchForm.hidden = !punching;
    auditForm.hidden = !auditing;
    document.getElementById('tab-login').classList.toggle('active', !registering);
    document.getElementById('tab-register').classList.toggle('active', registering);
    document.getElementById('tab-punch').classList.toggle('active', punching);
    document.getElementById('tab-audit').classList.toggle('active', auditing);
    document.getElementById('tab-login').setAttribute('aria-selected', String(!registering && !punching && !auditing));
    document.getElementById('tab-register').setAttribute('aria-selected', String(registering));
    document.getElementById('tab-punch').setAttribute('aria-selected', String(punching));
    document.getElementById('tab-audit').setAttribute('aria-selected', String(auditing));
    setFeedback(punching
      ? 'A verificação biométrica é opcional; ela nunca bloqueia a marcação de jornada.'
      : auditing
        ? 'Exceções são sinais para revisão humana, não conclusões de fraude.'
        : 'Para começar, escolha uma opção de acesso.');
    updateProgress(0, 'Três capturas ajudam a reduzir erros');
    if (punching || auditing) {
      stopCamera();
    } else {
      setFeedback('Ativando a câmera para o modo facial…');
      ensureCamera()
        .then(() => setFeedback('Câmera ativa. Posicione seu rosto no guia.'))
        .catch((error) => setFeedback(error.message, 'error'));
    }
  }

  function stopCamera() {
    cameraRequestId += 1;
    cameraStartPromise = null;
    if (stream) stream.getTracks().forEach((track) => track.stop());
    stream = null;
    video.srcObject = null;
    placeholder.hidden = false;
    cameraState.classList.remove('active', 'capturing');
    cameraState.innerHTML = '<span class="status-dot"></span> CÂMERA DESLIGADA';
    faceGuide.classList.remove('quality-good', 'quality-bad');
    cameraTitle.textContent = 'Câmera pronta para iniciar';
  }

  async function attemptOptionalFace(workerRef) {
    if (!navigator.onLine) {
      return { status: 'unavailable', assertion: null };
    }
    try {
      const descriptors = await captureDescriptors();
      const descriptorEnvelope = await encryptDescriptors(descriptors);
      const result = await postJson('/api/biometric/verify', { name: workerRef, descriptorEnvelope });
      return { status: result.status, assertion: result.assertion };
    } catch (error) {
      setFeedback(`Ponto preservado. Verificação facial pendente: ${error.message}`, 'error');
      return {
        status: error.status === 401 ? 'review_required' : 'unavailable',
        assertion: null,
      };
    } finally {
      stopCamera();
    }
  }

  async function submitPunch(event) {
    event.preventDefault();
    if (busy) return;
    busy = true;
    const button = document.getElementById('punch-button');
    const buttonText = button.querySelector('span:first-child');
    const originalText = buttonText.textContent;
    button.disabled = true;
    buttonText.textContent = 'Registrando…';
    const workerRef = new FormData(punchForm).get('workerRef');
    let verification = { status: 'not_requested', assertion: null };
    let eventRecord = null;
    try {
      if (document.getElementById('optional-face').checked) {
        verification = await attemptOptionalFace(workerRef);
      }
      eventRecord = await window.OperSyncroOutbox.createPunch({
        workerRef,
        type: document.getElementById('punch-type').value,
        verificationStatus: verification.status,
        biometricAssertion: verification.assertion,
        padStatus: 'not_configured',
      });

      if (document.getElementById('optional-location').checked && navigator.onLine) {
        const position = await window.OperSyncroOutbox.getPosition();
        if (position) window.OperSyncroOutbox.setPositionForSync(eventRecord.eventId, position);
      }

      const syncResult = await window.OperSyncroOutbox.sync();
      const status = document.getElementById('outbox-status');
      if (syncResult.synced) {
        const geoStatus = document.getElementById('optional-location').checked
          ? ` Geofence: ${syncResult.receipt.geofence.status} (${syncResult.receipt.geofence.accuracyBand}).`
          : '';
        setFeedback(
          `Marcação registrada e sincronizada. A verificação não substitui a conferência da jornada.${geoStatus}`,
          'success'
        );
        status.textContent = `Comprovante recebido. ID: ${eventRecord.eventId}`;
      } else {
        setFeedback('Marcação salva provisoriamente neste dispositivo. Ela ainda não tem comprovante do servidor.', 'success');
        status.textContent = `${syncResult.pending} marcação(ões) aguardando sincronização. Mantenha este navegador e os dados locais.`;
      }
      showToast('Marcação registrada. Falhas de biometria ou rede não a bloqueiam.');
      punchForm.reset();
    } catch (error) {
      if (eventRecord) {
        const pending = await window.OperSyncroOutbox.queueCount();
        setFeedback('Marcação salva provisoriamente neste dispositivo; sincronização pendente.', 'success');
        document.getElementById('outbox-status').textContent =
          `${pending} marcação(ões) aguardando sincronização. Detalhe: ${error.message}`;
      } else {
        setFeedback(`Não foi possível salvar a marcação localmente: ${error.message}`, 'error');
      }
      showToast(error.message, 'error');
    } finally {
      stopCamera();
      busy = false;
      button.disabled = false;
      buttonText.textContent = originalText;
    }
  }

  async function refreshOutboxStatus(initial = false) {
    try {
      const count = await window.OperSyncroOutbox.queueCount();
      if (count) {
        document.getElementById('outbox-status').textContent =
          `${count} marcação(ões) provisória(s) aguardando sincronização.`;
      } else if (initial) {
        document.getElementById('outbox-status').textContent = 'Nenhuma marcação pendente de sincronização.';
      }
    } catch (error) {
      document.getElementById('outbox-status').textContent = `Armazenamento offline indisponível: ${error.message}`;
    }
  }

  async function loadExceptions() {
    const token = document.getElementById('audit-token').value.trim();
    const actor = document.getElementById('audit-actor').value.trim();
    const container = document.getElementById('exception-list');
    container.replaceChildren();
    if (!token) {
      container.textContent = 'Informe o token de auditoria antes de carregar as exceções.';
      return;
    }
    try {
      const response = await fetch('/api/audit/exceptions', {
        headers: { Authorization: `Bearer ${token}` },
        credentials: 'same-origin',
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Não foi possível carregar as exceções.');
      if (!result.exceptions.length) {
        container.textContent = 'Nenhuma exceção pendente.';
        return;
      }
      for (const exception of result.exceptions) {
        const card = document.createElement('article');
        card.className = 'exception-card';
        const heading = document.createElement('strong');
        heading.textContent = `${exception.workerRef} · ${exception.type}`;
        const details = document.createElement('p');
        details.textContent = `${exception.reason} · ${exception.clientTimestamp}`;
        const reason = document.createElement('input');
        reason.type = 'text';
        reason.maxLength = 500;
        reason.placeholder = 'Justificativa da revisão';
        const actions = document.createElement('div');
        actions.className = 'exception-actions';
        for (const [action, label] of [['resolve', 'Resolver'], ['contest', 'Contestar']]) {
          const reviewButton = document.createElement('button');
          reviewButton.type = 'button';
          reviewButton.className = 'secondary-button';
          reviewButton.textContent = label;
          reviewButton.addEventListener('click', async () => {
            try {
              if (!token) {
                throw new Error('Informe o token de auditoria antes de registrar a revisão.');
              }
              const reviewResponse = await fetch(`/api/audit/exceptions/${encodeURIComponent(exception.eventId)}/review`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
                body: JSON.stringify({ action, reason: reason.value, actor }),
              });
              const reviewResult = await reviewResponse.json();
              if (!reviewResponse.ok) throw new Error(reviewResult.error || 'Não foi possível registrar a revisão.');
              await loadExceptions();
            } catch (error) {
              showToast(error.message, 'error');
            }
          });
          actions.append(reviewButton);
        }
        card.append(heading, details, reason, actions);
        container.append(card);
      }
    } catch (error) {
      container.textContent = error.message;
    }
  }

  async function refreshSession() {
    if (!navigator.onLine) return;
    const response = await fetch('/api/session', { credentials: 'same-origin' });
    if (!response.ok) return;
    const session = await response.json();
    if (!session.authenticated) return;
    stopCamera();
    loginForm.hidden = true;
    registerForm.hidden = true;
    document.querySelector('.auth-tabs').hidden = true;
    signedIn.hidden = false;
    document.getElementById('welcome-name').textContent = session.name;
  }

  loginForm.addEventListener('submit', (event) => {
    event.preventDefault();
    submitForm(loginForm, document.getElementById('login-button'), '/api/login');
  });
  registerForm.addEventListener('submit', (event) => {
    event.preventDefault();
    submitForm(registerForm, document.getElementById('register-button'), '/api/register');
  });
  document.getElementById('tab-login').addEventListener('click', () => selectTab('login'));
  document.getElementById('tab-register').addEventListener('click', () => selectTab('register'));
  document.getElementById('tab-punch').addEventListener('click', () => selectTab('punch'));
  document.getElementById('tab-audit').addEventListener('click', () => selectTab('audit'));
  punchForm.addEventListener('submit', submitPunch);
  document.getElementById('audit-load').addEventListener('click', loadExceptions);
  document.getElementById('audit-verify').addEventListener('click', async () => {
    const token = document.getElementById('audit-token').value.trim();
    if (!token) {
      showToast('Informe o token de auditoria antes de verificar a cadeia.', 'error');
      return;
    }
    try {
      const response = await fetch('/api/audit/verify', {
        headers: { Authorization: `Bearer ${token}` },
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Não foi possível verificar a cadeia.');
      showToast(result.valid
        ? `Cadeia íntegra: ${result.verifiedEntries} evento(s) verificado(s).`
        : `Cadeia inconsistente após ${result.verifiedEntries} evento(s).`, result.valid ? '' : 'error');
    } catch (error) {
      showToast(error.message, 'error');
    }
  });
  document.getElementById('logout-button').addEventListener('click', async () => {
    try {
      const response = await fetch('/api/logout', { method: 'POST', credentials: 'same-origin' });
      if (!response.ok) throw new Error('Não foi possível encerrar a sessão.');
      signedIn.hidden = true;
      document.querySelector('.auth-tabs').hidden = false;
      selectTab('login');
      showToast('Sessão encerrada.');
    } catch (error) {
      showToast(error.message, 'error');
    }
  });

  refreshSession().catch((error) => {
    if (navigator.onLine) showToast(`Não foi possível consultar a sessão atual: ${error.message}`, 'error');
  });
  refreshOutboxStatus(true);
  if (!document.querySelector('.auth-tabs').hidden) {
    setFeedback('Ativando a câmera para o modo facial…');
    ensureCamera()
      .then(() => setFeedback('Câmera ativa. Posicione seu rosto no guia.'))
      .catch((error) => setFeedback(error.message, 'error'));
  }
  window.addEventListener('punch-synced', (event) => {
    if (event.detail.reviewRequired) setFeedback('Marcação sincronizada e encaminhada para revisão humana.', 'success');
    else setFeedback('Marcação offline sincronizada; comprovante do servidor recebido.', 'success');
    document.getElementById('outbox-status').textContent =
      `Marcação sincronizada. ID: ${event.detail.receipt.eventId}`;
    refreshOutboxStatus();
  });
  window.addEventListener('punch-sync-error', (event) => {
    document.getElementById('outbox-status').textContent = `Sincronização pendente: ${event.detail}`;
  });
  window.addEventListener('online', () => {
    refreshSession().catch((error) => showToast(`Não foi possível consultar a sessão atual: ${error.message}`, 'error'));
  });
  window.addEventListener('beforeunload', () => {
    stopCamera();
  });
})();
