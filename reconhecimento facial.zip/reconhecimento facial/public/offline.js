(() => {
  const DATABASE_NAME = 'opersyncro-outbox';
  const DATABASE_VERSION = 1;
  const STORAGE_NAME = 'state';
  const QUEUE_NAME = 'queue';
  let databasePromise;
  let positionForSync = null;

  function openDatabase() {
    if (databasePromise) return databasePromise;
    databasePromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORAGE_NAME)) db.createObjectStore(STORAGE_NAME, { keyPath: 'id' });
        if (!db.objectStoreNames.contains(QUEUE_NAME)) db.createObjectStore(QUEUE_NAME, { keyPath: 'eventId' });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    return databasePromise;
  }

  async function transaction(storeName, mode, operation) {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, mode);
      const store = tx.objectStore(storeName);
      let result;
      try {
        result = operation(store);
      } catch (error) {
        reject(error);
        return;
      }
      tx.oncomplete = () => resolve(result?.result);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error || new Error('A transação do armazenamento local foi cancelada.'));
    });
  }

  function bytesToBase64Url(bytes) {
    let binary = '';
    for (const byte of bytes) binary += String.fromCharCode(byte);
    return btoa(binary).replace(/\+/gu, '-').replace(/\//gu, '_').replace(/=+$/u, '');
  }

  function base64UrlToBytes(value) {
    const base64 = value.replace(/-/gu, '+').replace(/_/gu, '/');
    const binary = atob(base64 + '='.repeat((4 - base64.length % 4) % 4));
    return Uint8Array.from(binary, (character) => character.charCodeAt(0));
  }

  function canonicalJson(value) {
    if (value === null || typeof value !== 'object') return JSON.stringify(value);
    if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
    return `{${Object.keys(value).sort().map((key) =>
      `${JSON.stringify(key)}:${canonicalJson(value[key])}`
    ).join(',')}}`;
  }

  async function getDevice() {
    let device = await transaction(STORAGE_NAME, 'readonly', (store) => store.get('device'));
    if (device) return device;
    const keyPair = await crypto.subtle.generateKey(
      { name: 'ECDSA', namedCurve: 'P-256' },
      false,
      ['sign', 'verify']
    );
    const publicKey = await crypto.subtle.exportKey('jwk', keyPair.publicKey);
    device = {
      deviceId: crypto.randomUUID(),
      keyPair,
      publicKey,
      sequence: 0,
      aesKey: await crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']),
    };
    await transaction(STORAGE_NAME, 'readwrite', (store) => store.put({ ...device, id: 'device' }));
    return device;
  }

  async function encryptQueuedEvent(device, value) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const plaintext = new TextEncoder().encode(JSON.stringify(value));
    const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, device.aesKey, plaintext);
    return { iv: bytesToBase64Url(iv), ciphertext: bytesToBase64Url(new Uint8Array(ciphertext)) };
  }

  async function decryptQueuedEvent(device, item) {
    const plaintext = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: base64UrlToBytes(item.iv) },
      device.aesKey,
      base64UrlToBytes(item.ciphertext)
    );
    return JSON.parse(new TextDecoder().decode(plaintext));
  }

  async function createPunch({ workerRef, type, verificationStatus, biometricAssertion, padStatus }) {
    const device = await getDevice();
    device.sequence += 1;
    await transaction(STORAGE_NAME, 'readwrite', (store) => store.put({ ...device, id: 'device' }));
    const event = {
      eventId: crypto.randomUUID(),
      deviceId: device.deviceId,
      sequence: device.sequence,
      workerRef: workerRef.trim(),
      type,
      clientTimestamp: new Date().toISOString(),
      verificationStatus,
      biometricAssertion: biometricAssertion || null,
      padStatus,
      source: navigator.onLine ? 'online' : 'offline',
    };
    const signature = bytesToBase64Url(new Uint8Array(await crypto.subtle.sign(
      { name: 'ECDSA', hash: 'SHA-256' },
      device.keyPair.privateKey,
      new TextEncoder().encode(canonicalJson(event))
    )));
    const queued = await encryptQueuedEvent(device, { event, signature });
    await transaction(QUEUE_NAME, 'readwrite', (store) =>
      store.add({ eventId: event.eventId, ...queued, queuedAt: event.clientTimestamp })
    );
    return event;
  }

  async function getPosition() {
    if (!navigator.geolocation) return null;
    try {
      return await new Promise((resolve) => {
        navigator.geolocation.getCurrentPosition(
          ({ coords }) => resolve({
            latitude: coords.latitude,
            longitude: coords.longitude,
            accuracy: coords.accuracy,
          }),
          () => resolve(null),
          { enableHighAccuracy: false, maximumAge: 30000, timeout: 4000 }
        );
      });
    } catch {
      return null;
    }
  }

  async function registerDevice(device) {
    const response = await fetch('/api/devices/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify({ deviceId: device.deviceId, publicKey: device.publicKey }),
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Não foi possível registrar este dispositivo.');
  }

  async function sync() {
    if (!navigator.onLine) return { synced: 0, pending: await queueCount(), offline: true };
    const syncPosition = positionForSync;
    positionForSync = null;
    const device = await getDevice();
    await registerDevice(device);
    const pending = await transaction(QUEUE_NAME, 'readonly', (store) => store.getAll());
    const ordered = await Promise.all(pending.map(async (item) => ({
      item,
      signedEvent: await decryptQueuedEvent(device, item),
    })));
    ordered.sort((left, right) => left.signedEvent.event.sequence - right.signedEvent.event.sequence);
    let synced = 0;
    let lastReceipt = null;
    for (const { item, signedEvent } of ordered) {
      const body = { ...signedEvent };
      if (syncPosition?.eventId === item.eventId) body.position = syncPosition.position;
      const response = await fetch('/api/punches', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Idempotency-Key': item.eventId,
        },
        credentials: 'same-origin',
        body: JSON.stringify(body),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'A marcação continua pendente de sincronização.');
      await transaction(QUEUE_NAME, 'readwrite', (store) => store.delete(item.eventId));
      synced += 1;
      lastReceipt = result.receipt;
      window.dispatchEvent(new CustomEvent('punch-synced', { detail: result }));
    }
    return { synced, pending: await queueCount(), offline: false, receipt: lastReceipt };
  }

  async function queueCount() {
    return transaction(QUEUE_NAME, 'readonly', (store) => store.count());
  }

  window.OperSyncroOutbox = {
    createPunch,
    queueCount,
    sync,
    getPosition,
    setPositionForSync(eventId, position) { positionForSync = { eventId, position }; },
  };

  window.addEventListener('online', () => {
    sync().catch((error) => window.dispatchEvent(new CustomEvent('punch-sync-error', { detail: error.message })));
  });
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js').catch((error) => {
        console.error('Não foi possível habilitar o cache offline:', error);
      });
    });
  }
})();
