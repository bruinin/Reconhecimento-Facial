$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot
$healthUrl = 'http://127.0.0.1:3000/health'

function Test-FaceAccessServer {
  try {
    $health = Invoke-RestMethod -Uri $healthUrl -TimeoutSec 2
    return $health.status -eq 'ok'
  } catch {
    return $false
  }
}

try {
  if (-not (Test-FaceAccessServer)) {
    if (-not (Test-Path (Join-Path $projectRoot 'node_modules'))) {
      throw 'As dependencias nao estao instaladas. Execute npm install na pasta do aplicativo.'
    }

    $logDirectory = Join-Path $env:LOCALAPPDATA 'FaceAccess\logs'
    New-Item -ItemType Directory -Path $logDirectory -Force | Out-Null
    Start-Process -FilePath 'node' `
      -ArgumentList 'server.js' `
      -WorkingDirectory $projectRoot `
      -WindowStyle Hidden `
      -RedirectStandardOutput (Join-Path $logDirectory 'server.log') `
      -RedirectStandardError (Join-Path $logDirectory 'server-error.log') | Out-Null

    $ready = $false
    for ($attempt = 0; $attempt -lt 30; $attempt += 1) {
      Start-Sleep -Seconds 1
      if (Test-FaceAccessServer) {
        $ready = $true
        break
      }
    }
    if (-not $ready) {
      throw "O servidor não ficou pronto. Consulte os logs em $logDirectory."
    }
  }

  Start-Process 'http://localhost:3000'
} catch {
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.MessageBox]::Show(
    $_.Exception.Message,
    'Face Access - falha ao iniciar',
    [System.Windows.Forms.MessageBoxButtons]::OK,
    [System.Windows.Forms.MessageBoxIcon]::Error
  ) | Out-Null
  exit 1
}
