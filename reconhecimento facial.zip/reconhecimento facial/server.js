const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const express = require('express');
const {
  normalizeName,
  validateDescriptors,
  matchDescriptors,
} = require('./src/face-utils');
const {
  canonicalJson,
  validatePunchEvent,
  classifyGeofence,
  isSignedPunchValid,
  UUID_PATTERN,
} = require('./src/punch-utils');

const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const DATA_DIR = path.resolve(process.env.FACE_DATA_DIR || path.join(ROOT, 'data'));
const PUBLIC_DIR = path.join(ROOT, 'public');
const MODEL_DIR = path.join(ROOT, 'node_modules', '@vladmandic', 'face-api', 'model');
const FACE_API_BUNDLE = path.join(ROOT, 'node_modules', '@vladmandic', 'face-api', 'dist', 'face-api.js');
const SESSION_TTL_SECONDS = 8 * 60 * 60;
const LOGIN_THRESHOLD = 0.48;
const VERIFICATION_POLICY_VERSION = 'face-access-demo-v1';
const FACE_MODEL_VERSION = '@vladmandic/face-api@1.7.15/ssd-mobilenetv1+face-recognition';
const PAD_STATUS = 'not_configured';
const PAD_POLICY_VERSION = 'pad-absent-v1';
const GEOFENCE_POLICY_VERSION = 'haversine-accuracy-band-v1';
const ATTEMPT_WINDOW_MS = 15 * 60 * 1000;
const MAX_ATTEMPTS = 5;
const activeSessions = new Map();
const biometricAssertions = new Map();
const biometricTransportKeys = crypto.generateKeyPairSync('rsa', {
  modulusLength: 3072,
  publicExponent: 0x10001,
});
const biometricPublicDer = biometricTransportKeys.publicKey.export({ type: 'spki', format: 'der' });
const biometricKeyId = crypto.createHash('sha256').update(biometricPublicDer).digest('base64url');
const biometricPublicJwk = biometricTransportKeys.publicKey.export({ format: 'jwk' });

function readPerimeter() {
  const latitude = process.env.GEOFENCE_LATITUDE;
  const longitude = process.env.GEOFENCE_LONGITUDE;
  const radiusMeters = process.env.GEOFENCE_RADIUS_METERS;
  if ([latitude, longitude, radiusMeters].every((value) => value === undefined)) return null;
  const perimeter = {
    latitude: Number(latitude),
    longitude: Number(longitude),
    radiusMeters: Number(radiusMeters),
  };
  if (!Number.isFinite(perimeter.latitude) || perimeter.latitude < -90 || perimeter.latitude > 90 ||
    !Number.isFinite(perimeter.longitude) || perimeter.longitude < -180 || perimeter.longitude > 180 ||
    !Number.isFinite(perimeter.radiusMeters) || perimeter.radiusMeters <= 0 || perimeter.radiusMeters > 10000) {
    throw new Error('Configure GEOFENCE_LATITUDE, GEOFENCE_LONGITUDE e GEOFENCE_RADIUS_METERS com valores válidos.');
  }
  return perimeter;
}

const perimeter = readPerimeter();

fs.mkdirSync(DATA_DIR, { recursive: true });

function loadVaultKey() {
  if (process.env.FACE_VAULT_KEY) {
    const key = Buffer.from(process.env.FACE_VAULT_KEY, 'base64');
    if (key.length !== 32) throw new Error('FACE_VAULT_KEY deve conter uma chave base64 de 32 bytes.');
    return key;
  }

  const keyPath = path.join(DATA_DIR, '.vault-key');
  try {
    return fs.readFileSync(keyPath);
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }

  const key = crypto.randomBytes(32);
  try {
    fs.writeFileSync(keyPath, key, { flag: 'wx', mode: 0o600 });
    return key;
  } catch (error) {
    if (error.code !== 'EEXIST') throw error;
    return fs.readFileSync(keyPath);
  }
}

const vaultKey = loadVaultKey();
if (vaultKey.length !== 32) throw new Error('A chave local do cofre deve conter exatamente 32 bytes.');
const indexKey = crypto.createHmac('sha256', vaultKey).update('username-index').digest();
const sessionKey = crypto.createHmac('sha256', vaultKey).update('session-signing').digest();
const auditKey = crypto.createHmac('sha256', vaultKey).update('audit-chain-signing').digest();

function encrypt(value) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', vaultKey, iv);
  const ciphertext = Buffer.concat([cipher.update(JSON.stringify(value), 'utf8'), cipher.final()]);
  return [iv, cipher.getAuthTag(), ciphertext].map((part) => part.toString('base64')).join('.');
}

function decrypt(value) {
  const [encodedIv, encodedTag, encodedCiphertext] = value.split('.');
  const decipher = crypto.createDecipheriv('aes-256-gcm', vaultKey, Buffer.from(encodedIv, 'base64'));
  decipher.setAuthTag(Buffer.from(encodedTag, 'base64'));
  const plaintext = Buffer.concat([
    decipher.update(Buffer.from(encodedCiphertext, 'base64')),
    decipher.final(),
  ]).toString('utf8');
  return JSON.parse(plaintext);
}

class BiometricEnvelopeError extends Error {}

function decryptDescriptorEnvelope(envelope) {
  if (!envelope || typeof envelope !== 'object' || envelope.keyId !== biometricKeyId ||
    typeof envelope.wrappedKey !== 'string' || typeof envelope.iv !== 'string' ||
    typeof envelope.ciphertext !== 'string') {
    throw new BiometricEnvelopeError('Pacote biométrico cifrado inválido ou expirado.');
  }
  try {
    const key = crypto.privateDecrypt({
      key: biometricTransportKeys.privateKey,
      oaepHash: 'sha256',
      padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
    }, Buffer.from(envelope.wrappedKey, 'base64url'));
    if (key.length !== 32) throw new BiometricEnvelopeError('Chave de sessão biométrica inválida.');
    const encryptedBytes = Buffer.from(envelope.ciphertext, 'base64url');
    const iv = Buffer.from(envelope.iv, 'base64url');
    if (encryptedBytes.length < 16 || encryptedBytes.length > 16 * 1024 || iv.length !== 12) {
      throw new BiometricEnvelopeError('Tamanho do pacote biométrico inválido.');
    }
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
    decipher.setAuthTag(encryptedBytes.subarray(encryptedBytes.length - 16));
    const plaintext = Buffer.concat([
      decipher.update(encryptedBytes.subarray(0, encryptedBytes.length - 16)),
      decipher.final(),
    ]).toString('utf8');
    return JSON.parse(plaintext);
  } catch (error) {
    if (error instanceof BiometricEnvelopeError) throw error;
    throw new BiometricEnvelopeError('Pacote biométrico cifrado inválido ou expirado.');
  }
}

function usernameKey(name) {
  return crypto.createHmac('sha256', indexKey).update(name.toLocaleLowerCase('pt-BR')).digest('hex');
}

function makeSession(name) {
  const sid = crypto.randomBytes(24).toString('base64url');
  const exp = Math.floor(Date.now() / 1000) + SESSION_TTL_SECONDS;
  for (const [id, expiry] of activeSessions) {
    if (expiry <= Math.floor(Date.now() / 1000)) activeSessions.delete(id);
  }
  activeSessions.set(sid, exp);
  const payload = Buffer.from(JSON.stringify({
    name,
    sid,
    exp,
  })).toString('base64url');
  const signature = crypto.createHmac('sha256', sessionKey).update(payload).digest('base64url');
  return `${payload}.${signature}`;
}

function readSession(token) {
  if (typeof token !== 'string') return null;
  const [payload, signature, extra] = token.split('.');
  if (!payload || !signature || extra) return null;
  const expected = crypto.createHmac('sha256', sessionKey).update(payload).digest();
  let actual;
  try {
    actual = Buffer.from(signature, 'base64url');
  } catch {
    return null;
  }
  if (actual.length !== expected.length || !crypto.timingSafeEqual(actual, expected)) return null;
  try {
    const session = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    if (typeof session.name !== 'string' || typeof session.sid !== 'string' || !Number.isInteger(session.exp) ||
      session.exp <= Math.floor(Date.now() / 1000)) return null;
    if (activeSessions.get(session.sid) !== session.exp) return null;
    return session;
  } catch {
    return null;
  }
}

const database = new DatabaseSync(path.join(DATA_DIR, 'face-access.sqlite'));
database.exec(`
  PRAGMA journal_mode = WAL;
  CREATE TABLE IF NOT EXISTS users (
    user_key TEXT PRIMARY KEY,
    encrypted_name TEXT NOT NULL,
    encrypted_descriptors TEXT NOT NULL,
    created_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS biometric_attempts (
    attempt_id TEXT PRIMARY KEY,
    user_key TEXT NOT NULL,
    status TEXT NOT NULL,
    model_version TEXT NOT NULL,
    policy_version TEXT NOT NULL,
    created_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS punch_devices (
    device_id TEXT PRIMARY KEY,
    public_key_jwk TEXT NOT NULL,
    created_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS punch_events (
    event_id TEXT PRIMARY KEY,
    device_id TEXT NOT NULL,
    sequence INTEGER NOT NULL,
    worker_ref TEXT NOT NULL,
    event_type TEXT NOT NULL,
    client_timestamp TEXT NOT NULL,
    received_at TEXT NOT NULL,
    source TEXT NOT NULL,
    verification_status TEXT NOT NULL,
    pad_status TEXT NOT NULL,
    geofence_status TEXT NOT NULL,
    geofence_accuracy_band TEXT NOT NULL,
    sequence_conflict INTEGER NOT NULL,
    canonical_event TEXT NOT NULL,
    device_signature TEXT NOT NULL,
    previous_hash TEXT NOT NULL,
    event_hash TEXT NOT NULL UNIQUE,
    receipt_mac TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS audit_ledger (
    ledger_id INTEGER PRIMARY KEY AUTOINCREMENT,
    entity_id TEXT NOT NULL,
    entry_type TEXT NOT NULL,
    canonical_payload TEXT NOT NULL,
    previous_hash TEXT NOT NULL,
    entry_hash TEXT NOT NULL UNIQUE,
    entry_mac TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS punch_events_device_sequence ON punch_events (device_id, sequence);
  CREATE TABLE IF NOT EXISTS punch_exceptions (
    event_id TEXT PRIMARY KEY REFERENCES punch_events(event_id),
    reason TEXT NOT NULL,
    created_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS audit_reviews (
    review_id TEXT PRIMARY KEY,
    event_id TEXT NOT NULL REFERENCES punch_exceptions(event_id),
    action TEXT NOT NULL,
    reason TEXT NOT NULL,
    actor TEXT NOT NULL,
    created_at TEXT NOT NULL
  );
  CREATE TRIGGER IF NOT EXISTS punch_events_no_update
    BEFORE UPDATE ON punch_events BEGIN SELECT RAISE(ABORT, 'punch events are append-only'); END;
  CREATE TRIGGER IF NOT EXISTS punch_events_no_delete
    BEFORE DELETE ON punch_events BEGIN SELECT RAISE(ABORT, 'punch events are append-only'); END;
  CREATE TRIGGER IF NOT EXISTS biometric_attempts_no_update
    BEFORE UPDATE ON biometric_attempts BEGIN SELECT RAISE(ABORT, 'biometric attempts are append-only'); END;
  CREATE TRIGGER IF NOT EXISTS biometric_attempts_no_delete
    BEFORE DELETE ON biometric_attempts BEGIN SELECT RAISE(ABORT, 'biometric attempts are append-only'); END;
  CREATE TRIGGER IF NOT EXISTS punch_exceptions_no_update
    BEFORE UPDATE ON punch_exceptions BEGIN SELECT RAISE(ABORT, 'punch exceptions are append-only'); END;
  CREATE TRIGGER IF NOT EXISTS punch_exceptions_no_delete
    BEFORE DELETE ON punch_exceptions BEGIN SELECT RAISE(ABORT, 'punch exceptions are append-only'); END;
  CREATE TRIGGER IF NOT EXISTS audit_reviews_no_update
    BEFORE UPDATE ON audit_reviews BEGIN SELECT RAISE(ABORT, 'audit reviews are append-only'); END;
  CREATE TRIGGER IF NOT EXISTS audit_reviews_no_delete
    BEFORE DELETE ON audit_reviews BEGIN SELECT RAISE(ABORT, 'audit reviews are append-only'); END;
  CREATE TRIGGER IF NOT EXISTS audit_ledger_no_update
    BEFORE UPDATE ON audit_ledger BEGIN SELECT RAISE(ABORT, 'audit ledger is append-only'); END;
  CREATE TRIGGER IF NOT EXISTS audit_ledger_no_delete
    BEFORE DELETE ON audit_ledger BEGIN SELECT RAISE(ABORT, 'audit ledger is append-only'); END;
`);
const biometricAttemptColumns = new Set(
  database.prepare('PRAGMA table_info(biometric_attempts)').all().map((column) => column.name)
);
if (!biometricAttemptColumns.has('model_version')) {
  database.exec("ALTER TABLE biometric_attempts ADD COLUMN model_version TEXT NOT NULL DEFAULT 'legacy'");
}
if (!biometricAttemptColumns.has('policy_version')) {
  database.exec("ALTER TABLE biometric_attempts ADD COLUMN policy_version TEXT NOT NULL DEFAULT 'legacy'");
}
const punchColumns = new Set(database.prepare('PRAGMA table_info(punch_events)').all().map((column) => column.name));
if (!punchColumns.has('device_signature')) {
  database.exec("ALTER TABLE punch_events ADD COLUMN device_signature TEXT NOT NULL DEFAULT ''");
}
const findUser = database.prepare('SELECT encrypted_name, encrypted_descriptors FROM users WHERE user_key = ?');
const addUser = database.prepare(
  'INSERT INTO users (user_key, encrypted_name, encrypted_descriptors, created_at) VALUES (?, ?, ?, ?)'
);
const findDevice = database.prepare('SELECT public_key_jwk FROM punch_devices WHERE device_id = ?');
const addDevice = database.prepare('INSERT INTO punch_devices (device_id, public_key_jwk, created_at) VALUES (?, ?, ?)');
const findPunch = database.prepare(`
  SELECT event_hash, receipt_mac, received_at, geofence_status, geofence_accuracy_band,
    canonical_event, device_signature
  FROM punch_events WHERE event_id = ?
`);
const findSequence = database.prepare('SELECT event_id FROM punch_events WHERE device_id = ? AND sequence = ?');
const maxDeviceSequence = database.prepare('SELECT MAX(sequence) AS sequence FROM punch_events WHERE device_id = ?');
const lastAuditEvent = database.prepare('SELECT entry_hash FROM audit_ledger ORDER BY ledger_id DESC LIMIT 1');
const insertAuditEntry = database.prepare(`
  INSERT INTO audit_ledger (entity_id, entry_type, canonical_payload, previous_hash, entry_hash, entry_mac)
  VALUES (?, ?, ?, ?, ?, ?)
`);
const insertPunch = database.prepare(`
  INSERT INTO punch_events (
    event_id, device_id, sequence, worker_ref, event_type, client_timestamp,
    received_at, source, verification_status, pad_status, geofence_status,
    geofence_accuracy_band, sequence_conflict, canonical_event, device_signature,
    previous_hash, event_hash, receipt_mac
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
`);
const insertException = database.prepare(
  'INSERT INTO punch_exceptions (event_id, reason, created_at) VALUES (?, ?, ?)'
);
const insertReview = database.prepare(
  'INSERT INTO audit_reviews (review_id, event_id, action, reason, actor, created_at) VALUES (?, ?, ?, ?, ?, ?)'
);
const insertBiometricAttempt = database.prepare(`
  INSERT INTO biometric_attempts (attempt_id, user_key, status, model_version, policy_version, created_at)
  VALUES (?, ?, ?, ?, ?, ?)
`);

const app = express();
const attempts = new Map();
app.disable('x-powered-by');
app.get('/health', (_req, res) => {
  res.set('Cache-Control', 'no-store');
  return res.json({ status: 'ok' });
});
app.use((req, res, next) => {
  res.set({
    'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; media-src 'self' blob:; font-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'",
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Permissions-Policy': 'camera=(self), microphone=(), geolocation=()',
    'Cross-Origin-Opener-Policy': 'same-origin',
  });
  next();
});
app.use(express.json({ limit: '24kb', strict: true }));

function limitAttempts(req, res, next) {
  const now = Date.now();
  const key = `${req.ip}:${req.path}`;
  const current = attempts.get(key);
  if (!current || current.resetAt <= now) {
    attempts.set(key, { count: 1, resetAt: now + ATTEMPT_WINDOW_MS });
    return next();
  }
  if (current.count >= MAX_ATTEMPTS) {
    return res.status(429).json({ error: 'Muitas tentativas. Aguarde 15 minutos e tente novamente.' });
  }
  current.count += 1;
  return next();
}

app.get('/vendor/face-api.js', (_req, res, next) => res.sendFile(FACE_API_BUNDLE, (error) => error && next(error)));
app.use('/models', express.static(MODEL_DIR, { dotfiles: 'deny', fallthrough: false, maxAge: '1d' }));
app.use(express.static(PUBLIC_DIR, { dotfiles: 'deny', index: 'index.html' }));

app.get('/api/biometric/key', (_req, res) => {
  res.set('Cache-Control', 'no-store');
  return res.json({ keyId: biometricKeyId, publicKey: biometricPublicJwk });
});

function verifyBiometric(name, envelope) {
  const descriptors = decryptDescriptorEnvelope(envelope);
  if (!validateDescriptors(descriptors)) {
    return { invalid: true };
  }
  const key = usernameKey(name);
  const user = findUser.get(key);
  if (!user) {
    recordBiometricAttempt(key, 'no_match');
    return { verified: false };
  }
  const enrolledName = decrypt(user.encrypted_name);
  const templates = decrypt(user.encrypted_descriptors);
  const verified = matchDescriptors(descriptors, templates, LOGIN_THRESHOLD);
  recordBiometricAttempt(key, verified ? 'face_match' : 'no_match');
  return { verified, enrolledName, userKey: key };
}

function appendAuditEntry(entityId, entryType, payload) {
  const canonicalPayload = encrypt(payload);
  const previousHash = lastAuditEvent.get()?.entry_hash || '0'.repeat(64);
  const entryHash = crypto.createHash('sha256').update(previousHash).update(canonicalPayload).digest('hex');
  const entryMac = crypto.createHmac('sha256', auditKey).update(entryHash).digest('base64url');
  insertAuditEntry.run(entityId, entryType, canonicalPayload, previousHash, entryHash, entryMac);
  return { previousHash, entryHash, entryMac };
}

function recordBiometricAttempt(userKey, status) {
  const attempt = {
    attemptId: crypto.randomUUID(),
    userKey,
    status,
    modelVersion: FACE_MODEL_VERSION,
    policyVersion: VERIFICATION_POLICY_VERSION,
    createdAt: new Date().toISOString(),
  };
  database.exec('BEGIN IMMEDIATE');
  try {
    insertBiometricAttempt.run(
      attempt.attemptId,
      attempt.userKey,
      attempt.status,
      attempt.modelVersion,
      attempt.policyVersion,
      attempt.createdAt
    );
    appendAuditEntry(attempt.attemptId, 'biometric_attempt', attempt);
    database.exec('COMMIT');
  } catch (error) {
    database.exec('ROLLBACK');
    throw error;
  }
}

app.post('/api/register', limitAttempts, (req, res) => {
  const name = normalizeName(req.body?.name);
  if (!name) return res.status(400).json({ error: 'Informe um nome válido para o cadastro.' });

  let descriptors;
  try {
    descriptors = decryptDescriptorEnvelope(req.body?.descriptorEnvelope);
  } catch (error) {
    if (error instanceof BiometricEnvelopeError) {
      return res.status(400).json({ error: 'Pacote facial cifrado inválido ou expirado. Tente novamente.' });
    }
    throw error;
  }
  if (!validateDescriptors(descriptors)) {
    return res.status(400).json({ error: 'Conclua as três capturas faciais válidas.' });
  }

  const key = usernameKey(name);
  if (findUser.get(key)) return res.status(409).json({ error: 'Já existe um cadastro com esse nome.' });

  try {
    addUser.run(key, encrypt(name), encrypt(descriptors), new Date().toISOString());
  } catch (error) {
    if (error.code === 'ERR_SQLITE_CONSTRAINT_PRIMARYKEY') {
      return res.status(409).json({ error: 'Já existe um cadastro com esse nome.' });
    }
    throw error;
  }
  return res.status(201).json({ message: 'Cadastro facial concluído.' });
});

app.post('/api/biometric/verify', limitAttempts, (req, res) => {
  const name = normalizeName(req.body?.name);
  if (!name) return res.status(400).json({ error: 'Informe o nome do cadastro.' });
  let result;
  try {
    result = verifyBiometric(name, req.body?.descriptorEnvelope);
  } catch (error) {
    if (error instanceof BiometricEnvelopeError) {
      return res.status(400).json({ error: 'Pacote facial cifrado inválido ou expirado. Tente novamente.' });
    }
    throw error;
  }
  if (result.invalid) return res.status(400).json({ error: 'As capturas faciais são inválidas.' });
  if (!result.verified) {
    return res.status(401).json({ error: 'Não foi possível confirmar a identidade. O ponto ainda pode ser registrado.' });
  }
  const now = Date.now();
  for (const [token, assertion] of biometricAssertions) {
    if (assertion.expiresAt <= now) biometricAssertions.delete(token);
  }
  const assertion = crypto.randomBytes(32).toString('base64url');
  biometricAssertions.set(assertion, {
    userKey: result.userKey,
    status: 'review_required',
    expiresAt: now + 60_000,
  });
  attempts.delete(`${req.ip}:${req.path}`);
  return res.json({
    status: 'review_required',
    assertion,
    padStatus: PAD_POLICY_VERSION,
  });
});

app.post('/api/login', limitAttempts, (req, res) => {
  const name = normalizeName(req.body?.name);
  if (!name) return res.status(400).json({ error: 'Informe o nome do cadastro.' });
  let result;
  try {
    result = verifyBiometric(name, req.body?.descriptorEnvelope);
  } catch (error) {
    if (error instanceof BiometricEnvelopeError) {
      return res.status(400).json({ error: 'Pacote facial cifrado inválido ou expirado. Tente novamente.' });
    }
    throw error;
  }
  if (result.invalid) return res.status(400).json({ error: 'As capturas faciais são inválidas.' });
  if (!result.verified) {
    return res.status(401).json({ error: 'Não foi possível confirmar a identidade. Confira os dados e tente novamente.' });
  }

  attempts.delete(`${req.ip}:${req.path}`);
  res.cookie('face_session', makeSession(result.enrolledName), {
    httpOnly: true,
    sameSite: 'strict',
    secure: req.secure,
    path: '/',
    maxAge: SESSION_TTL_SECONDS * 1000,
  });
  return res.json({ message: 'Identidade confirmada.' });
});

app.get('/api/session', (req, res) => {
  const session = readSession(req.cookies?.face_session || parseCookies(req.headers.cookie).face_session);
  if (!session) return res.json({ authenticated: false });
  return res.json({ authenticated: true, name: session.name });
});

app.post('/api/logout', (req, res) => {
  const session = readSession(parseCookies(req.headers.cookie).face_session);
  if (session) activeSessions.delete(session.sid);
  res.clearCookie('face_session', {
    httpOnly: true,
    sameSite: 'strict',
    secure: req.secure,
    path: '/',
  });
  return res.json({ message: 'Sessão encerrada.' });
});

app.post('/api/devices/register', (req, res) => {
  const { deviceId, publicKey } = req.body || {};
  if (typeof deviceId !== 'string' || !UUID_PATTERN.test(deviceId) ||
    !publicKey || publicKey.kty !== 'EC' || publicKey.crv !== 'P-256' ||
    typeof publicKey.x !== 'string' || typeof publicKey.y !== 'string') {
    return res.status(400).json({ error: 'Credencial de dispositivo inválida.' });
  }

  let keyObject;
  try {
    keyObject = crypto.createPublicKey({ key: publicKey, format: 'jwk' });
  } catch {
    return res.status(400).json({ error: 'Chave pública do dispositivo inválida.' });
  }
  if (keyObject.asymmetricKeyType !== 'ec' || keyObject.asymmetricKeyDetails.namedCurve !== 'prime256v1') {
    return res.status(400).json({ error: 'A chave deve usar ECDSA P-256.' });
  }

  const existing = findDevice.get(deviceId);
  const encodedKey = canonicalJson(publicKey);
  if (existing && existing.public_key_jwk !== encodedKey) {
    return res.status(409).json({ error: 'Este identificador de dispositivo já está vinculado a outra chave.' });
  }
  if (!existing) addDevice.run(deviceId, encodedKey, new Date().toISOString());
  return res.json({ registered: true });
});

app.post('/api/punches', (req, res) => {
  const { event, signature, position } = req.body || {};
  if (!validatePunchEvent(event) || req.get('Idempotency-Key') !== event.eventId) {
    return res.status(400).json({ error: 'Marcação inválida ou chave de idempotência ausente.' });
  }
  const existingPunch = findPunch.get(event.eventId);
  if (existingPunch) {
    if (canonicalJson(decrypt(existingPunch.canonical_event)) !== canonicalJson(event) ||
      existingPunch.device_signature !== signature) {
      return res.status(409).json({ error: 'A chave de idempotência já foi usada com outro conteúdo.' });
    }
    return res.json({
      duplicate: true,
      receipt: {
        eventId: event.eventId,
        receivedAt: existingPunch.received_at,
        geofence: {
          status: existingPunch.geofence_status,
          accuracyBand: existingPunch.geofence_accuracy_band,
        },
        eventHash: existingPunch.event_hash,
        mac: existingPunch.receipt_mac,
      },
    });
  }

  const device = findDevice.get(event.deviceId);
  if (!device) return res.status(401).json({ error: 'Dispositivo ainda não registrado para sincronização.' });
  let publicKey;
  try {
    publicKey = crypto.createPublicKey({ key: JSON.parse(device.public_key_jwk), format: 'jwk' });
  } catch (error) {
    console.error('Chave registrada de dispositivo inválida:', error);
    return res.status(500).json({ error: 'Não foi possível verificar a assinatura do dispositivo.' });
  }
  if (!isSignedPunchValid(event, signature, publicKey)) {
    return res.status(401).json({ error: 'Assinatura da marcação inválida.' });
  }

  const lastSequence = maxDeviceSequence.get(event.deviceId).sequence;
  const sequenceConflict = Boolean(findSequence.get(event.deviceId, event.sequence)) ||
    event.sequence !== (lastSequence === null ? 1 : lastSequence + 1);
  const geofence = classifyGeofence(position, perimeter);
  let assertionValid = false;
  let verificationStatus = 'not_requested';
  if (event.biometricAssertion) {
    const assertion = biometricAssertions.get(event.biometricAssertion);
    biometricAssertions.delete(event.biometricAssertion);
    const normalizedWorker = normalizeName(event.workerRef);
    assertionValid = Boolean(assertion && assertion.expiresAt > Date.now() &&
      normalizedWorker && assertion.userKey === usernameKey(normalizedWorker));
  }
  if (event.verificationStatus !== 'not_requested' || event.biometricAssertion) {
    verificationStatus = 'review_required';
  }
  const padStatus = PAD_STATUS;
  const reasons = [];
  if (verificationStatus !== 'not_requested') {
    reasons.push(assertionValid ? 'pad_not_configured' : 'biometric_assertion_unverified');
  }
  if (event.source === 'offline') reasons.push('offline_synchronized');
  if (perimeter && geofence.status !== 'inside') reasons.push(`geofence_${geofence.status}`);
  if (sequenceConflict) reasons.push('device_sequence_conflict');

  const receivedAt = new Date().toISOString();
  const ledgerPayload = {
    event,
    signature,
    receivedAt,
    geofence,
    verificationStatus,
    padStatus,
    versions: {
      verificationPolicy: VERIFICATION_POLICY_VERSION,
      faceModel: FACE_MODEL_VERSION,
      padPolicy: PAD_POLICY_VERSION,
      geofencePolicy: GEOFENCE_POLICY_VERSION,
    },
    sequenceConflict,
    reasons,
  };
  const canonicalPayload = encrypt(ledgerPayload);
  const previousHash = lastAuditEvent.get()?.entry_hash || '0'.repeat(64);
  const eventHash = crypto.createHash('sha256')
    .update(previousHash)
    .update(canonicalPayload)
    .digest('hex');
  const receiptMac = crypto.createHmac('sha256', auditKey).update(eventHash).digest('base64url');
  const dbEvent = encrypt(event);

  database.exec('BEGIN IMMEDIATE');
  try {
    insertPunch.run(
      event.eventId,
      event.deviceId,
      event.sequence,
      encrypt(event.workerRef.trim()),
      event.type,
      event.clientTimestamp,
      receivedAt,
      event.source,
      verificationStatus,
      padStatus,
      geofence.status,
      geofence.accuracyBand,
      sequenceConflict ? 1 : 0,
      dbEvent,
      signature,
      previousHash,
      eventHash,
      receiptMac
    );
    insertAuditEntry.run(event.eventId, 'punch', canonicalPayload, previousHash, eventHash, receiptMac);
    if (reasons.length) insertException.run(event.eventId, encrypt(reasons.join(',')), receivedAt);
    database.exec('COMMIT');
  } catch (error) {
    database.exec('ROLLBACK');
    throw error;
  }

  return res.status(201).json({
    duplicate: false,
    receipt: {
      eventId: event.eventId,
      receivedAt,
      geofence,
      verificationStatus,
      padStatus,
      eventHash,
      mac: receiptMac,
    },
    reviewRequired: reasons.length > 0,
  });
});

function authorizeAuditReview(req, res) {
  const configuredToken = process.env.AUDIT_REVIEW_TOKEN;
  const supplied = req.get('Authorization')?.replace(/^Bearer\s+/u, '');
  if (!configuredToken) {
    res.status(503).json({ error: 'Painel de auditoria desativado: configure AUDIT_REVIEW_TOKEN.' });
    return false;
  }
  if (typeof supplied !== 'string') {
    res.status(401).json({ error: 'Autorização de auditoria necessária.' });
    return false;
  }
  const expected = Buffer.from(configuredToken);
  const actual = Buffer.from(supplied);
  if (actual.length !== expected.length || !crypto.timingSafeEqual(actual, expected)) {
    res.status(401).json({ error: 'Autorização de auditoria inválida.' });
    return false;
  }
  return true;
}

app.get('/api/audit/exceptions', (req, res) => {
  if (!authorizeAuditReview(req, res)) return;
  const rows = database.prepare(`
    SELECT e.event_id AS eventId, e.worker_ref AS workerRef, e.event_type AS type,
      e.client_timestamp AS clientTimestamp, e.received_at AS receivedAt,
      x.reason AS reason
    FROM punch_exceptions x
    JOIN punch_events e ON e.event_id = x.event_id
    WHERE NOT EXISTS (SELECT 1 FROM audit_reviews r WHERE r.event_id = x.event_id)
    ORDER BY e.received_at DESC LIMIT 200
  `).all();
  return res.json({
    exceptions: rows.map((row) => ({
      ...row,
      workerRef: decrypt(row.workerRef),
      reason: decrypt(row.reason),
    })),
  });
});

app.post('/api/audit/exceptions/:eventId/review', (req, res) => {
  if (!authorizeAuditReview(req, res)) return;
  const { eventId } = req.params;
  const { action, reason } = req.body || {};
  const actor = typeof req.body?.actor === 'string' ? req.body.actor.trim() : '';
  if (!UUID_PATTERN.test(eventId) || !['resolve', 'contest'].includes(action) ||
    typeof reason !== 'string' || reason.trim().length < 3 || reason.trim().length > 500 ||
    actor.length < 2 || actor.length > 80) {
    return res.status(400).json({ error: 'Informe uma ação, responsável e justificativa válidos.' });
  }
  if (!database.prepare('SELECT 1 FROM punch_exceptions WHERE event_id = ?').get(eventId)) {
    return res.status(404).json({ error: 'Exceção não encontrada.' });
  }
  if (database.prepare('SELECT 1 FROM audit_reviews WHERE event_id = ?').get(eventId)) {
    return res.status(409).json({ error: 'Esta exceção já possui uma revisão registrada.' });
  }
  const createdAt = new Date().toISOString();
  const review = {
    reviewId: crypto.randomUUID(),
    eventId,
    action,
    reason: reason.trim(),
    actor,
    createdAt,
  };
  const canonicalPayload = encrypt(review);
  const previousHash = lastAuditEvent.get()?.entry_hash || '0'.repeat(64);
  const eventHash = crypto.createHash('sha256').update(previousHash).update(canonicalPayload).digest('hex');
  const receiptMac = crypto.createHmac('sha256', auditKey).update(eventHash).digest('base64url');
  database.exec('BEGIN IMMEDIATE');
  try {
    insertReview.run(review.reviewId, eventId, action, encrypt(reason.trim()), encrypt(actor), createdAt);
    insertAuditEntry.run(review.reviewId, 'review', canonicalPayload, previousHash, eventHash, receiptMac);
    database.exec('COMMIT');
  } catch (error) {
    database.exec('ROLLBACK');
    throw error;
  }
  return res.status(201).json({ reviewId: review.reviewId, eventHash, mac: receiptMac });
});

app.get('/api/audit/verify', (req, res) => {
  if (!authorizeAuditReview(req, res)) return;
  const entries = database.prepare(`
    SELECT entity_id, entry_type, canonical_payload, previous_hash, entry_hash, entry_mac
    FROM audit_ledger ORDER BY ledger_id
  `).all();
  let previousHash = '0'.repeat(64);
  for (const entry of entries) {
    const expectedHash = crypto.createHash('sha256')
      .update(previousHash)
      .update(entry.canonical_payload)
      .digest('hex');
    const expectedMac = crypto.createHmac('sha256', auditKey).update(expectedHash).digest();
    const actualMac = Buffer.from(entry.entry_mac, 'base64url');
    if (entry.previous_hash !== previousHash || entry.entry_hash !== expectedHash ||
      actualMac.length !== expectedMac.length || !crypto.timingSafeEqual(actualMac, expectedMac)) {
      return res.json({ valid: false, verifiedEntries: entries.indexOf(entry) });
    }
    let payload;
    try {
      payload = decrypt(entry.canonical_payload);
    } catch {
      return res.json({ valid: false, verifiedEntries: entries.indexOf(entry) });
    }
    if (entry.entry_type === 'punch') {
      const punch = database.prepare(`
        SELECT canonical_event, device_signature, event_hash, previous_hash,
          device_id, sequence, worker_ref, event_type, client_timestamp,
          received_at, source, verification_status, pad_status, geofence_status,
          geofence_accuracy_band, sequence_conflict, receipt_mac
        FROM punch_events WHERE event_id = ?
      `).get(entry.entity_id);
      let storedEvent;
      let storedWorkerRef;
      try {
        storedEvent = punch && decrypt(punch.canonical_event);
        storedWorkerRef = punch && decrypt(punch.worker_ref);
      } catch {
        return res.json({ valid: false, verifiedEntries: entries.indexOf(entry) });
      }
      if (!punch || canonicalJson(storedEvent) !== canonicalJson(payload.event) ||
        punch.device_id !== payload.event.deviceId || punch.sequence !== payload.event.sequence ||
        storedWorkerRef !== payload.event.workerRef || punch.event_type !== payload.event.type ||
        punch.client_timestamp !== payload.event.clientTimestamp ||
        punch.received_at !== payload.receivedAt || punch.source !== payload.event.source ||
        punch.verification_status !== payload.verificationStatus ||
        punch.pad_status !== payload.padStatus ||
        punch.geofence_status !== payload.geofence.status ||
        punch.geofence_accuracy_band !== payload.geofence.accuracyBand ||
        Boolean(punch.sequence_conflict) !== payload.sequenceConflict ||
        punch.device_signature !== payload.signature || punch.event_hash !== entry.entry_hash ||
        punch.previous_hash !== entry.previous_hash || punch.receipt_mac !== entry.entry_mac) {
        return res.json({ valid: false, verifiedEntries: entries.indexOf(entry) });
      }
      const device = findDevice.get(payload.event.deviceId);
      if (!device) return res.json({ valid: false, verifiedEntries: entries.indexOf(entry) });
      let devicePublicKey;
      try {
        devicePublicKey = crypto.createPublicKey({ key: JSON.parse(device.public_key_jwk), format: 'jwk' });
      } catch {
        return res.json({ valid: false, verifiedEntries: entries.indexOf(entry) });
      }
      if (!isSignedPunchValid(payload.event, payload.signature, devicePublicKey)) {
        return res.json({ valid: false, verifiedEntries: entries.indexOf(entry) });
      }
      const exception = database.prepare(`
        SELECT reason, created_at FROM punch_exceptions WHERE event_id = ?
      `).get(entry.entity_id);
      let exceptionReason;
      try {
        exceptionReason = exception && decrypt(exception.reason);
      } catch {
        return res.json({ valid: false, verifiedEntries: entries.indexOf(entry) });
      }
      if (!Array.isArray(payload.reasons)) {
        return res.json({ valid: false, verifiedEntries: entries.indexOf(entry) });
      }
      if (payload.reasons.length) {
        if (!exception || exception.created_at !== payload.receivedAt ||
          exceptionReason !== payload.reasons.join(',')) {
          return res.json({ valid: false, verifiedEntries: entries.indexOf(entry) });
        }
      } else if (exception) {
        return res.json({ valid: false, verifiedEntries: entries.indexOf(entry) });
      }
    } else if (entry.entry_type === 'review') {
      const review = database.prepare(`
        SELECT review_id, event_id, action, reason, actor, created_at
        FROM audit_reviews WHERE review_id = ?
      `).get(entry.entity_id);
      let storedReview;
      try {
        storedReview = review && {
          reviewId: review.review_id,
          eventId: review.event_id,
          action: review.action,
          reason: decrypt(review.reason),
          actor: decrypt(review.actor),
          createdAt: review.created_at,
        };
      } catch {
        return res.json({ valid: false, verifiedEntries: entries.indexOf(entry) });
      }
      if (!review || canonicalJson(storedReview) !== canonicalJson(payload)) {
        return res.json({ valid: false, verifiedEntries: entries.indexOf(entry) });
      }
    } else if (entry.entry_type === 'biometric_attempt') {
      const attempt = database.prepare(`
        SELECT attempt_id, user_key, status, model_version, policy_version, created_at
        FROM biometric_attempts WHERE attempt_id = ?
      `).get(entry.entity_id);
      if (!attempt || canonicalJson({
        attemptId: attempt.attempt_id,
        userKey: attempt.user_key,
        status: attempt.status,
        modelVersion: attempt.model_version,
        policyVersion: attempt.policy_version,
        createdAt: attempt.created_at,
      }) !== canonicalJson(payload)) {
        return res.json({ valid: false, verifiedEntries: entries.indexOf(entry) });
      }
    } else {
      return res.json({ valid: false, verifiedEntries: entries.indexOf(entry) });
    }
    previousHash = entry.entry_hash;
  }
  return res.json({ valid: true, verifiedEntries: entries.length });
});

function parseCookies(header = '') {
  return Object.fromEntries(header.split(';').map((part) => {
    const separator = part.indexOf('=');
    if (separator < 0) return ['', ''];
    return [part.slice(0, separator).trim(), decodeURIComponent(part.slice(separator + 1).trim())];
  }).filter(([name]) => name));
}

app.use((error, _req, res, _next) => {
  if (res.headersSent) return;
  if (error.type === 'entity.parse.failed') return res.status(400).json({ error: 'Requisição JSON inválida.' });
  if (error.type === 'entity.too.large') return res.status(413).json({ error: 'Requisição excede o limite permitido.' });
  console.error('Falha ao processar requisição:', error);
  return res.status(500).json({ error: 'Erro interno. Consulte o log do servidor.' });
});

app.listen(PORT, '127.0.0.1', () => {
  console.log(`Face Access disponível em http://localhost:${PORT}`);
  console.log('Modo local: use apenas para testes; não exponha este servidor na rede.');
});
