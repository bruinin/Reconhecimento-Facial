const DESCRIPTOR_LENGTH = 128;

function normalizeName(value) {
  if (typeof value !== 'string') return null;
  const name = value.trim().normalize('NFKC');
  if (name.length < 2 || name.length > 60 || /[\u0000-\u001f\u007f]/u.test(name)) return null;
  return name;
}

function validateDescriptors(value) {
  if (!Array.isArray(value) || value.length !== 3) return false;
  return value.every((descriptor) =>
    Array.isArray(descriptor) &&
    descriptor.length === DESCRIPTOR_LENGTH &&
    descriptor.every((number) => Number.isFinite(number) && number >= -1 && number <= 1)
  );
}

function euclideanDistance(left, right) {
  if (left.length !== DESCRIPTOR_LENGTH || right.length !== DESCRIPTOR_LENGTH) {
    throw new RangeError('Descritores faciais devem ter 128 valores.');
  }

  let sum = 0;
  for (let index = 0; index < DESCRIPTOR_LENGTH; index += 1) {
    const difference = left[index] - right[index];
    sum += difference * difference;
  }
  return Math.sqrt(sum);
}

function matchDescriptors(probes, templates, threshold = 0.48) {
  if (!validateDescriptors(probes) || !Array.isArray(templates) || templates.length < 1) return false;
  if (!templates.every((item) => Array.isArray(item) && item.length === DESCRIPTOR_LENGTH &&
    item.every((number) => Number.isFinite(number)))) return false;

  const distances = probes
    .map((probe) => Math.min(...templates.map((template) => euclideanDistance(probe, template))))
    .sort((left, right) => left - right);

  return distances[1] <= threshold;
}

module.exports = { normalizeName, validateDescriptors, euclideanDistance, matchDescriptors };
