const crypto = require('node:crypto');

const PUNCH_TYPES = new Set(['clock_in', 'break_start', 'break_end', 'clock_out']);
const VERIFICATION_STATES = new Set([
  'not_requested',
  'verified',
  'inconclusive',
  'unavailable',
  'spoof_suspected',
  'review_required',
]);
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/iu;

function canonicalJson(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
  return `{${Object.keys(value).sort().map((key) =>
    `${JSON.stringify(key)}:${canonicalJson(value[key])}`
  ).join(',')}}`;
}

function validatePunchEvent(event) {
  if (!event || typeof event !== 'object' || Array.isArray(event)) return false;
  if (!UUID_PATTERN.test(event.eventId) || !UUID_PATTERN.test(event.deviceId)) return false;
  if (!Number.isSafeInteger(event.sequence) || event.sequence < 1) return false;
  if (typeof event.workerRef !== 'string' || event.workerRef.trim().length < 1 ||
    event.workerRef.length > 64 || /[\u0000-\u001f\u007f]/u.test(event.workerRef)) return false;
  if (!PUNCH_TYPES.has(event.type) || !VERIFICATION_STATES.has(event.verificationStatus)) return false;
  if (!Object.hasOwn(event, 'biometricAssertion') ||
    (event.biometricAssertion !== null &&
      (typeof event.biometricAssertion !== 'string' || event.biometricAssertion.length > 128))) return false;
  if (typeof event.clientTimestamp !== 'string' || !Number.isFinite(Date.parse(event.clientTimestamp))) return false;
  if (event.source !== 'online' && event.source !== 'offline') return false;
  if (!['not_configured', 'available', 'unavailable'].includes(event.padStatus)) return false;
  return true;
}

function haversineMeters(latitude1, longitude1, latitude2, longitude2) {
  const earthRadiusMeters = 6371008.8;
  const radians = (degrees) => (degrees * Math.PI) / 180;
  const latitudeDelta = radians(latitude2 - latitude1);
  const longitudeDelta = radians(longitude2 - longitude1);
  const value = Math.sin(latitudeDelta / 2) ** 2 +
    Math.cos(radians(latitude1)) * Math.cos(radians(latitude2)) *
    Math.sin(longitudeDelta / 2) ** 2;
  return earthRadiusMeters * 2 * Math.atan2(Math.sqrt(value), Math.sqrt(1 - value));
}

function classifyGeofence(position, perimeter) {
  if (!perimeter || !position ||
    !Number.isFinite(position.latitude) || position.latitude < -90 || position.latitude > 90 ||
    !Number.isFinite(position.longitude) || position.longitude < -180 || position.longitude > 180 ||
    !Number.isFinite(position.accuracy) || position.accuracy < 0) {
    return { status: 'unknown', accuracyBand: 'unknown' };
  }

  const accuracyBand = position.accuracy <= 25 ? 'high' : position.accuracy <= 100 ? 'medium' : 'low';
  const distance = haversineMeters(
    position.latitude,
    position.longitude,
    perimeter.latitude,
    perimeter.longitude
  );
  const uncertainty = Math.max(position.accuracy, 0);
  if (distance + uncertainty <= perimeter.radiusMeters) return { status: 'inside', accuracyBand };
  if (distance - uncertainty > perimeter.radiusMeters) return { status: 'outside', accuracyBand };
  return { status: 'unknown', accuracyBand };
}

function isSignedPunchValid(event, signature, publicKey) {
  if (!validatePunchEvent(event) || typeof signature !== 'string' ||
    !/^[A-Za-z0-9_-]+$/u.test(signature)) return false;
  try {
    const signatureBytes = Buffer.from(signature, 'base64url');
    const key = signatureBytes.length === 64
      ? { key: publicKey, dsaEncoding: 'ieee-p1363' }
      : publicKey;
    return crypto.verify(
      'sha256',
      Buffer.from(canonicalJson(event)),
      key,
      signatureBytes
    );
  } catch {
    return false;
  }
}

module.exports = {
  canonicalJson,
  validatePunchEvent,
  haversineMeters,
  classifyGeofence,
  isSignedPunchValid,
  UUID_PATTERN,
};
