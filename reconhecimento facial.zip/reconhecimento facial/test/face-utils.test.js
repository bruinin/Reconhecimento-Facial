const test = require('node:test');
const assert = require('node:assert/strict');
const {
  normalizeName,
  validateDescriptors,
  euclideanDistance,
  matchDescriptors,
} = require('../src/face-utils');

const descriptor = (value = 0) => Array(128).fill(value);

test('normalizes names and rejects invalid input', () => {
  assert.equal(normalizeName('  Bruno  '), 'Bruno');
  assert.equal(normalizeName('Ｂｒｕｎｏ'), 'Bruno');
  assert.equal(normalizeName(' '), null);
  assert.equal(normalizeName('a'.repeat(61)), null);
  assert.equal(normalizeName('Ana\u0000'), null);
});

test('accepts only three bounded 128-value descriptors', () => {
  assert.equal(validateDescriptors([descriptor(), descriptor(), descriptor()]), true);
  assert.equal(validateDescriptors([descriptor(), descriptor()]), false);
  assert.equal(validateDescriptors([descriptor(), descriptor(), [0, 0]]), false);
  assert.equal(validateDescriptors([descriptor(), descriptor(), descriptor(2)]), false);
  assert.equal(validateDescriptors([descriptor(), descriptor(), descriptor(Number.NaN)]), false);
});

test('calculates Euclidean descriptor distance', () => {
  assert.equal(euclideanDistance(descriptor(), descriptor()), 0);
  assert.ok(Math.abs(euclideanDistance(descriptor(), descriptor(0.1)) - Math.sqrt(1.28)) < 1e-12);
  assert.throws(() => euclideanDistance([1], [1]), RangeError);
});

test('requires at least two of three probes to meet the match threshold', () => {
  const probes = [descriptor(), descriptor(0.01), descriptor(0.1)];
  assert.equal(matchDescriptors(probes, [descriptor()], 0.2), true);
  assert.equal(matchDescriptors([descriptor(0.05), descriptor(0.06), descriptor(0.07)], [descriptor()], 0.05), false);
  assert.equal(matchDescriptors(probes, [], 0.2), false);
});
