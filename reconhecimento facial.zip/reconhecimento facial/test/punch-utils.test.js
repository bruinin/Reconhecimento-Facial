const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const {
  canonicalJson,
  validatePunchEvent,
  haversineMeters,
  classifyGeofence,
  isSignedPunchValid,
} = require('../src/punch-utils');

const event = {
  eventId: 'a1a1a1a1-1111-4111-8111-a1a1a1a1a1a1',
  deviceId: 'b2b2b2b2-2222-4222-8222-b2b2b2b2b2b2',
  sequence: 1,
  workerRef: 'worker-001',
  type: 'clock_in',
  clientTimestamp: '2026-10-19T12:00:00.000Z',
  verificationStatus: 'not_requested',
  biometricAssertion: null,
  padStatus: 'not_configured',
  source: 'online',
};

test('canonical JSON is stable regardless of property insertion order', () => {
  assert.equal(canonicalJson({ b: 2, a: { d: 4, c: 3 } }), '{"a":{"c":3,"d":4},"b":2}');
  assert.equal(canonicalJson({ a: { c: 3, d: 4 }, b: 2 }), canonicalJson({ b: 2, a: { d: 4, c: 3 } }));
});

test('validates attendance events and their statuses', () => {
  assert.equal(validatePunchEvent(event), true);
  assert.equal(validatePunchEvent({ ...event, type: 'delete' }), false);
  assert.equal(validatePunchEvent({ ...event, verificationStatus: 'denied' }), false);
  assert.equal(validatePunchEvent({ ...event, workerRef: 'x\u0000y' }), false);
  assert.equal(validatePunchEvent({ ...event, sequence: 0 }), false);
});

test('computes geofence conservatively, accounting for GPS accuracy', () => {
  assert.ok(Math.abs(haversineMeters(0, 0, 0, 1) - 111195) < 100);
  const perimeter = { latitude: 0, longitude: 0, radiusMeters: 100 };
  assert.deepEqual(classifyGeofence({ latitude: 0, longitude: 0, accuracy: 10 }, perimeter),
    { status: 'inside', accuracyBand: 'high' });
  assert.deepEqual(classifyGeofence({ latitude: 0, longitude: 0.002, accuracy: 10 }, perimeter),
    { status: 'outside', accuracyBand: 'high' });
  assert.deepEqual(classifyGeofence({ latitude: 0, longitude: 0.001, accuracy: 25 }, perimeter),
    { status: 'unknown', accuracyBand: 'high' });
  assert.deepEqual(classifyGeofence(null, perimeter), { status: 'unknown', accuracyBand: 'unknown' });
});

test('verifies a device signature over the canonical event', () => {
  const keys = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  const signature = crypto.sign('sha256', Buffer.from(canonicalJson(event)), keys.privateKey).toString('base64url');
  assert.equal(isSignedPunchValid(event, signature, keys.publicKey), true);
  assert.equal(isSignedPunchValid({ ...event, workerRef: 'changed' }, signature, keys.publicKey), false);
});
